(*exercice 89*)

let composition (f:'a->'b) (g:'b->'c) : ('a->'c) =
  let h (x:'a) : 'c =
    let i=f x in let j=g i in j
  in h;;

let comp f g = fun x -> g(f(x));;

let composition2 (f:'a->'b*'c) (g:'b->'c->'d) : ('a->'d) =
  let h (x:'a) : 'd =
    let (i,j)=f x in let k=g i j in k
  in h;;

let curry (tab:'a array) : 'a list =
  let n=Array.length tab in
  let rec aux (i:int) (a:'a list) : 'a list =
    if(i<n)then
      let tmp=a@tab.(n)::[] in
      aux (i+1) (tmp)
    else (a)
  in aux 0 [];;


type 'a inflist = unit -> 'a contentsil
and 'a contentsil = Cons of 'a*'a inflist;;
let rec from n = fun () -> Cons (n, from (n + 1));;
let nat () = from 0;;
