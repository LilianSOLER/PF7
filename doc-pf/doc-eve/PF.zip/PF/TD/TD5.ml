(*exercice 108*)

let reverse (a: 'a array) : unit =
  let n = Array.length a
  in let rec aux (i:int) : unit =
       if i<n/2 then
       let tmp = a.(i) in a.(i) <- a.(n-1-i);
                          a.(n-i-1) <- tmp;
                          aux (i+1)
in aux 0;;
                          (*else ()(* () = ne rien faire en caml*)*)
let a =  [|1; 2; 3|];;
let test = reverse a;;
a;;

let mem_array (x:'a)(a:'a array) : int =
  let n = Array.length a in
  let rec aux (g : int) (d : int) : int =
    let m = (g+d)/2 in
    aux g m
  in aux 0 (n-1);; (*on passe pas de tableau mais des indices ds appels rec*)

         (*exercice 109*)
         (*a chaque fois new tab car tt elem d'un tab doivent avoir même type*)
(*Array.make a = créer tab facilement chaque case contient a*)

let array_map (f :'a ->'b) (a:'a array):('b array) =
             let n = Array.length a in
             if n = 0 then [||] else
               let b = Array.make n (f a.(0)) in
               let rec remplir (i:int) : unit =
                 if i < n then
                   begin
                   b.(i) <- f a.(i);
                   remplir (i+1)
                   end
               in remplir 1;
                  b;;

let array_to_list (a :'a array) :('a list) =
             let n = Array.length a in
               let rec aux (i:int) : 'a list =
                 if i = n then [] else
                   begin
                   a.(i)::(aux (i+1) )
                   end
               in aux 0;;
                  
let test2 = array_to_list [|1;2;3;4|];;

(*parcourir la liste pr avoir la taille de celle-ci puis une fois qu'on a n ok*)
