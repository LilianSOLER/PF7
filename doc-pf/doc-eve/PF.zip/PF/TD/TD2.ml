let c1 = (3,8);;
let c2 = (3,8);;

let b1 = c1==c2;;
let b2 = c1 =c2;;

let rec pgcd  = fun (b : int) (c : int): int ->  if (b < c) then pgcd (b-c) c else (if (b > c) then pgcd b (c-b) else b);;

(*let test = pgcd 6 12;;*)

(*exo23*)

let rec appartient_liste = fun (a: 'a list) (elem) : bool ->match a with
                                                            |[] -> false
                                                            |current::next-> if (current = elem) then true else appartient_liste next elem;;
let liste = [1;2;4;8;16;32;64;128];;
let test2 = appartient_liste liste 2;;

(*exo24*)
let rec (lmin: 'a list -> 'a) = fun liste -> match liste with
| [] -> failwith("Empty List")
| c::[] -> c
| c::t -> min c (lmin t);;

let rec minl = fun x1 l -> match l with
                           | [] -> x1
                           | x2 :: q -> min x1 (minl x2 q);;
lmin liste ;;
