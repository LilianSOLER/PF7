(*exo7*)
let rec fact = fun (n: int) -> if( n>1) then n*fact(n-1) else 1;;

(*exo8*)
let max = 0;;
let rec f2 = fun (a:int) -> fun (b:int) -> if( b <0) then failwith "exposant negatif" else if (b>0) then  a* f2 a (b-1) else 1;; (*non terminal*)

let rec puissw = fun a b c -> 
  if (b > 0) then
    puissw a (b-1) (c*a)
  else c
;;

let (puiss: int -> int -> int) = fun a b -> 
  if (b < 0) then 
    failwith "exponentiel négatif"
  else if (a = 1) then 1
  else 
    puissw a b 1;;
;;

let testf2 = puiss 2 5;;

let testf2 = f2 2 5;;

(*exo22*)
type liste
