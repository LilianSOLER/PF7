#load "qtparser.cmo";;
open Qtparser;;

(*QUADTREE*)
let z_2x2b = Noeud(Feuille(1),Feuille(1),Feuille(1),Feuille(1));; (*carre de zone blanche 2x2*)
let z1s = Noeud(z_2x2b, z_2x2b, Noeud(Feuille(0),Feuille(1),Feuille(1),Feuille(0)), z_2x2b);;
let z2s = Noeud(z_2x2b, z_2x2b,  z_2x2b, Noeud(Feuille(1),Feuille(0),Feuille(0),Feuille(1)));;
let z3s = Noeud( Noeud(Feuille(1),Feuille(1),Feuille(0),Feuille(1)),z_2x2b,z_2x2b, Noeud(Feuille(0),Feuille(0),Feuille(1),Feuille(1)));;
let z4s = Noeud(z_2x2b, Noeud(Feuille(1),Feuille(1),Feuille(1),Feuille(0)), Noeud(Feuille(0),Feuille(0),Feuille(1),Feuille(1)),z_2x2b);;
let smiley = Noeud(z1s,z2s,z3s,z4s);;

(*test visualisation*)
save_qt 8 1 smiley "test_smiley.pgm";;
let test = load_qt "test_smiley.pgm";;


(*exercice 50 tourner dans le sens trigo de 90°*)

let rec rot_pos =fun (q : quadtree): (quadtree) -> match q with
                                                   | Feuille(c) -> Feuille(c)
                                                   | Noeud(z1,z2,z3,z4) -> Noeud (rot_pos z2,rot_neg z3,rot_neg z4,rot_neg z1);;

(*test rot_pos*)
save_qt 8 1 (rot_pos smiley) "test_smiley.pgm";;
let test = load_qt "test_smiley.pgm";;

(*exercice 51 tourner dans le sens anti-trigo de 90°*)

let rec rot_neg =fun (q : quadtree): (quadtree) -> match q with
                                                   | Feuille(c) -> Feuille(c)
                                                   | Noeud(z1,z2,z3,z4) -> Noeud (rot_neg z4,rot_neg z1,rot_neg z2,rot_neg z3);;

(*test rot_neg*)
save_qt 8 1 (rot_neg smiley) "test_smiley.pgm";;
let test = load_qt "test_smiley.pgm";;

(*exercice 52 miroir horizontal*)
let rec miroir_hori =fun (q : quadtree): (quadtree) -> match q with
                                                   | Feuille(c) -> Feuille(c)
                                                   | Noeud(z1,z2,z3,z4) -> Noeud ( miroir_hori z4,miroir_hori z3, miroir_hori z2, miroir_hori z1);;

(*test miroir_hori*)
save_qt 8 1 (miroir_hori smiley) "test_smiley.pgm";;
let test = load_qt "test_smiley.pgm";;

(*exercice 53 miroir vertical*)
let rec miroir_vert =fun (q : quadtree): (quadtree) -> match q with
                                                   | Feuille(c) -> Feuille(c)
                                                   | Noeud(z1,z2,z3,z4) -> Noeud ( miroir_vert z2,miroir_vert z1, miroir_vert z4, miroir_vert z3);;

(*test miroir_vert*)
save_qt 8 1 (miroir_vert smiley) "test_smiley.pgm";;
let test = load_qt "test_smiley.pgm";;


(*exercice 54 inversion des couleurs *)
let rec inversion_video =fun (n: int)  (q : quadtree): (quadtree) -> match q with
                                                           | Feuille(c) -> if (c = 0) then Feuille (n) else Feuille(0) 
                                                           | Noeud(z1,z2,z3,z4) -> Noeud ( inversion_video n z1,inversion_video n z2, inversion_video n z3, inversion_video n z4);;

(*test inversion video*)
save_qt 8 1 (inversion_video 1 smiley) "test_smiley.pgm";;
let test = load_qt "test_smiley.pgm";;

(*exercice 55 parcours niveau de gris max*)
(*TODO voir niveau de gris max si c'est 0 ou 255 ----> max devient min*)
let rec gris_max = fun (q : quadtree): (int) -> match q with
                                                     | Feuille(c) -> c
                                                     | Noeud(z1,z2,z3,z4) -> max (max (gris_max z1) (gris_max z2)) (max (gris_max z3) (gris_max z4));;

(*test niveau gris max*)
let tmp = inversion_video 255 smiley;;
gris_max tmp;;

(*exercice 56 compare 2 quadtree*)


let rec compare = fun (qa : quadtree) (qb :quadtree): (bool) -> match qa,qb with
                                                                 | Feuille(ca), Feuille(cb) -> if (ca = cb) then true else failwith "pas même image"
                                                                 | Noeud(z1,z2,z3,z4), Feuille(c) -> if ((compare z1 z2) && (compare z3 z4)) = c then true else failwith "pas même image"
                                                                 | Feuille(c),Noeud(z1,z2,z3,z4) -> if ((compare z1 z2) &&  (compare z3 z4)) = c then true else failwith "pas même image"
                                                                 | Noeud(za1,za2,za3,za4), Noeud(zb1,zb2,zb3,zb4) -> 

                                                                                                                                                    
(*test niveau gris max*)
let tmp = inversion_video 255 smiley;;
gris_max tmp;;

(*exercice 58 transformation de quadtree en feuille*)
let rec min_quad = fun (q : quadtree) : quadtree -> match q with
                                                     | Feuille(c) -> Feuille(c)
                                                     | Noeud(z1,z2,z3,z4) -> match z1,z2,z3,z4 with
                                                                             | Feuille(c1), Feuille(c2), Feuille(c3), Feuille(c4) -> if (c1 =c2 && c2 = c3 && c3= c4) then Feuille (c1) else q 
                                                                             | _, _ , _, _ -> min_quad (Noeud(min_quad z1,min_quad z2, min_quad z3, min_quad z4));;
