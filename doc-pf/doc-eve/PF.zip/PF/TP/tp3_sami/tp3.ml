
(*Chapitre 3*)
(*fonction rebuild "reconstruit" la liste*)
(*let rec rebuild = fun liste -> match liste with
                            |[] -> []
                            |current::next -> current::rebuild next;;

let rec concat = fun l1 -> fun l2 -> match l1 with
                                      |[] -> rebuild l2
                                      |current::next -> current::concat next l2;;

let meme_article = fun (p : produit) (m : marque) (prix : int) (art : article): bool ->  let (p2,m2,prix2,s2) =art in (if(p==p2 && m==m2 && prix == prix2 && s2 >0) then true else false);;
-------------------------juste pour la syntaxe----------------------------*)

let rec rebuild = fun liste -> match liste with
                            |[] -> []
                            |current::next -> current::rebuild next;;

let rec concat = fun l1 -> fun l2 -> match l1 with
                                      |[] -> rebuild l2
                                      |current::next -> current::concat next l2;;


let rec renverser = fun (l : 'a list) -> match l with
                              |[] -> l 
                              |current::next ->  concat (renverser next) (current::[]);;

let l1 = 1::2::3::4::5::[];;
let test1 = renverser l1;;

let rec renverser_tr = fun (l1 : 'a list) (l2 : 'a list) -> match l1 with
                              |[] -> l2
                              |current::next -> (renverser_tr next (current::l2));;
let test2 = renverser_tr l1 l1;;

let rinit = Random.self_init();;

let rec liste_alea = fun (n : int): 'a list -> match n with
                                                    |0 -> []
                                                    |_ -> Random.int(100):: liste_alea (n-1);;
let test3 = liste_alea 10;;
let liste_per1 = liste_alea 20000;;
let liste_per2 = liste_alea 20000;;
let perf1 = Sys.time() in let _ = (renverser liste_per1) in Sys.time() -. perf1;;
let perf2 = Sys.time() in let _ = (renverser_tr liste_per2 []) in Sys.time() -. perf2;;
(*-------------------------------------------------------
Le coup dépend surtout des parcours de liste effectués.
la première fonction effectue plusieurs parcours de listes via la fonction concat et la fonction renverser. cela génere de multiples appels recursif. Cela explique la difference avec la seconde fonction renverse qui ne fai qu'un parcours de liste.)*)


(* FAIRE PREUVE COQ *)

(* exercice 40*)
type abint = Vide | Noeud of abint * int * abint
let ab8 = (Noeud(Noeud(Vide,6,Noeud(Vide,7,Vide)),8,Noeud(Vide,9,Vide)));;
let ab3 = Noeud(Noeud(Vide,2,Vide),3,Vide);;
let abr1 = Noeud(ab3,5,ab8);;

(*exercice 41*)
let rec mem = fun (n : int) (arbre : abint) : bool-> match arbre with
                                                     | Vide -> false
                                                     | Noeud(g,i,d) -> (if (n == i) then true else (if (n > i) then mem n d else mem n g));;
let test4 = mem 3 abr1;;

            (*exercice 42*)
let rec insert = fun (n : int) (arbre : abint) : abint-> match arbre with
                                                     | Vide -> Noeud(Vide,n,Vide)
                                                     | Noeud(g,i,d) -> (if (n == i) then Noeud(g,i,d) else if (n > i) then
                                                                          Noeud(g,i,(insert n d)) else Noeud((insert n g),i,d)) ;;
let test5 = insert 1 (insert 5 (insert 6 (Noeud(Vide,2,Vide))));;

let rec abrmind = fun (n : int) (arbre : abint) : int -> match arbre with
                                           | Vide -> n
                                           | Noeud(g,i,d) -> abrmind (min i n) d;;

let rec abrmaxg = fun (n : int) (arbre : abint) : int -> match arbre with
                                           | Vide -> n
                                           | Noeud(g,i,d) -> abrmaxg (max i n) g;;

let rec verif = fun (arbre : abint) : bool -> match arbre with
                                                 | Vide -> true
                                                 | Noeud(g,i,d) -> if ((abrmaxg i g) <= i) && ((abrmind i d) >= i) then true else false;;
(*recherche du max à gauche et du min à droite. si min = i et max = i alors c'est ok*)
let abr2 =  (Noeud(Noeud(Noeud(Vide,18,Vide),6,Noeud(Vide,7,Vide)),8,Noeud(Vide,9,Vide)));;

verif abr2;;
verif abr1;;
verif test5;;


(*exercice 45*)
let rec listToABR = fun (l : 'a list) : abint -> match l with
                                                 | [] -> Vide
                                                 | current::next -> insert current (listToABR next);;

let rec _ABRTolist = fun (arbre : abint) : 'a list -> match arbre with
                                                 | Vide -> []
                                                 | Noeud(g,i,d) -> (_ABRTolist g)@[i]@(_ABRTolist d) ;;

let triABR = fun (l : 'a list) :'a list ->
                                _ABRTolist (listToABR l);;

let l1 = 8::3::5::6::11::9::9::[];;
triABR l1;;

(*exercice 47*)
let isNBR = fun (g : int)(i : int)(d : int) : bool-> if (g <= i && i <= d) then true else false;;

let rec extremABR = fun (arbre : abint) : (int*int) -> match arbre with
                                                       | Vide -> failwith "ce noeud est vide"
                                                       | Noeud(g,i,d) -> match g,d with
                                                                         | Vide,Vide -> (i,i)
                                                                         | Vide, Noeud(_,_,_) -> let (minA,maxA) = extremABR(d) in  if(isNBR minA i maxA) then (i,maxA) else failwith "pas un abr"
                                                                         | Noeud(_,_,_), Vide -> let (minA,maxA) = extremABR(g) in  if(isNBR minA i maxA) then (minA,i) else failwith "pas un abr"
                                                                         | Noeud(_,_,_), Noeud(_,_,_)-> let (minA,maxA) = extremABR(g) in let (minB,maxB) = extremABR(d) in if(isNBR minA i maxB) then (minA,maxB) else failwith "pas un abr";;
                                                      
                                                       
let (t1,t2) = extremABR (listToABR l1);;
let fakeABR = Noeud(Noeud(Vide,18,Vide),9,Vide);;
extremABR fakeABR;;
(*exercice 48*)

let nv = fun(x:int):abint -> Noeud(Vide,x,Vide);;
(*juste pr raccourcir l'ecriture d'un noeud vide*)

(*
- x fait partie de l'arbre.
- si un entier i de l'arbre <= à x alors on l'insère dans l'arbre de gauche*)


let rec split = fun (x:int) (arbre : abint):(abint*abint)  -> match arbre with
                                                       | Vide -> failwith "ce noeud est vide"
                                                       | Noeud(g,i,d) -> match g,d with
                                                                         | Vide,Vide -> if (i <= x) then ((nv i),Vide) else (Vide,(nv i))
                                                                         | Vide, Noeud(_,_,_) -> if (i > x) then (Vide,insert i d) else let (a1,a2)=(split x d) in (insert i a1,a2)
                                                                         | Noeud(_,_,_), Vide -> if (i <= x) then (insert i g,Vide) else let (a1,a2)= (split x g) in (a1,insert i a2)
                                                                         | Noeud(_,_,_), Noeud(_,_,_)->  let (ag1,ag2) = (split x g) in let  (ad1,ad2) = (split x d) in (if (i <= x) then ((insert i ag1), ad2) else  (ag1,(insert i ad2)) );; 
(* | Noeud(_,_,_), Noeud(_,_,_)->  let (ag1,ag2) = (split x g) in let  (ad1,ad2) = (split x d) in (if (i <= x) then ((insert i ag1), ad2) else  (ag1,(insert i ad2)) );;*)

let ab7 = listToABR l1;;
split 9 ab7;;
let l2 = 1::7::6::4::5::3::2::8::9::[];;
let ab8 = listToABR l2;;
split 5 ab8;;(*marche pas avec le cas du noeud avec 2 fils car oublie de ag2 et ad1 à revoir !*)
