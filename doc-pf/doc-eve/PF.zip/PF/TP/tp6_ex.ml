(* Analyse descendante récursive sur une liste *)

(* Utilitaire pour les tests *)

let list_of_string s =
  let rec boucle s i n =
    if i = n then [] else s.[i] :: boucle s (i+1) n
  in boucle s 0 (String.length s)

(* Le type des fonctions qui épluchent une liste de terminaux *)
type 'term analist = 'term list -> 'term list (*une analist est liste de 'term *)

(* Le type des fonctions qui épluchent une liste et rendent un résultat *)
type ('r, 'term) ranalist = 'term list -> 'r * 'term list (*liste de couple d'un terme et d'une liste*)

exception Echec

(*fonction du tp5 qui peut *)
let terminal c : 't analist = fun l -> match l with
  | x :: l when x = c -> l
  | _ -> raise Echec


(* ------------------------------------------------------------ *)
(* Combinateurs d'analyseurs
   Sans calcul d'AST *)
(* ------------------------------------------------------------ *)

(* a suivi de b *)
let (+>) (a : 't analist) (b : 't analist) : 't analist =
  fun l -> let l = a l in b l

(* choix entre a ou b *)
let (+|) (a : 't analist) (b : 't analist) : 't analist =
  fun l -> try a l with Echec -> b l

(* ---------------------------------- *)
(* Grammaire non récursive *)

(* 
    S0  ::=  'x'
    S   ::=  '(' S0 ')'  |  'x'
*)

let p_S0 : char analist = terminal 'x'

let p_S : char analist =
    (terminal '('  +>  p_S0  +>  terminal ')')
 +| (terminal 'x')

(* Tests *)

let test s = p_S (list_of_string s)
let _ = test "(x)abc"
let _ = test "xabc"

(* ---------------------------------- *)
(* Grammaire récursive *)

(* 
    S0  ::=  'x'
    S   ::=  '(' S ')'  |  'x'
*)


(* 
   En OCaml, x |> f est une autre notation de f x.
   Le let rec impose l'explicitation d'au moins un argument,
   d'où le démarrage par fun l -> l |>
*)

let rec p_S : char analist = fun l ->  l |>
     (terminal '('  +>  p_S  +>  terminal ')')
  +| (terminal 'x')

let test s = p_S (list_of_string s)
let _ = test "(((x)))abc"
let _ = test "xabc"
let _ = test "((x))abc"
let _ = test "()abc"

(* ------------------------------------------------------------ *)
(* Combinateurs d'analyseurs
   Avec calcul d'AST *)
(* ------------------------------------------------------------ *)

(* Un type commun pour 't analist ou ('r, 't) ranalist *)
type ('x, 't) st = 't list -> 'x

(* a suivi de b, ce dernier pouvant rendre un résultat *)
let (+>) (a : 't analist) (b : ('x, 't) st) : ('x, 't) st =
  fun l -> let l = a l in b l

(* a rendant un résultat suivi de b, ce dernier pouvant rendre un résultat *)
let (++>) (a : ('r, 't) ranalist) (b : 'r -> ('x, 't) st) : ('x, 't) st =
  fun l -> let (x, l) = a l in b x l

(* Choix entre a ou b *)
let (+|) (a : ('x, 't) st) (b : ('x, 't) st) : ('x, 't) st =
  fun l -> try a l with Echec -> b l

(* *)
let return : 'r -> ('r, 't) ranalist =
  fun x l -> (x, l)

(* ---------------------------------- *)
(* 
    S0  ::=  'x'
    S   ::=  '(' S ')'  |  'x'
*)

type ast = Fin | Pa of ast

let rec p_S : (ast, char) ranalist = fun l ->  l |>
     (terminal '('  +>  p_S  ++>  fun a -> terminal ')'  +>  return (Pa (a)))
  +| (terminal 'x'  +>  return Fin)

let test s = p_S (list_of_string s)
let _ = test "(((x)))a(bc"
let _ = test "xabc"
let _ = test "()abc"

(* ---------------------------------- *)
(* Exemple avec récursion mutuelle

  B  ::=  (B)  |  C
  C  ::=  x    |  yC   |  zBC

 *)

type boite = Emb of boite | Cont of contenu
and contenu = X | Y of contenu | Z of boite * contenu

let rec p_B : (boite, char) ranalist = fun l ->  l |>
    (terminal '('  +>  p_B  ++>  fun b -> terminal ')'  +>  return (Emb (b)))
 +| (p_C  ++>  fun c -> return (Cont (c)))

and p_C : (contenu, char) ranalist = fun l ->  l |>
    (terminal 'x'  +>  return X)
 +| (terminal 'y'  +>  p_C  ++>  fun c -> return (Y (c)))
 +| (terminal 'z'  +>  p_B  ++>  fun b -> p_C  ++>  fun c -> return (Z (b, c)))

let _ = p_B (list_of_string "((yz(yyx)yx))a")

