(*exo1*)
let r = let x =7 in 6 * x;;
let a = (r-6) /6 -6
let o = r*r - x * x - 51
let u = let x =9 in if(x<9) then 9/(x-x) else (x+x)/9

(*exo2*)
let pi_sur_4 = 3.14/.4.
let dans_l_ordre = 1 < 2 && 2 < 3
let positif = let a =42 in if a>= 0 then true else false
let double_abs = let x = -2.7 in (if (x < 0.) then x else -.x)*.2.

(*exo3*)
type semaine = Lundi | Mardi | Mercredi | Jeudi | Vendredi | Samedi | Dimanche
type point2D = int*int
let o = (0,0)
type segment = point2D*point2D
type somme_fig= Carre of(segment) | Rectangle of (segment*segment) | Cercle of (point2D*segment)
let car1 = (0,1),(2,3)
let rect1 = ((0,1),(2,3)),((6,7),(4,5))
let cerc1 = (0,0),((0,0),(2,2))

(*exo4*)
type couleur = Rouge| Vert | Jaune | Bleu | Joker
type valeur = V1 | V2 | V3 | V4 | V5 | V6 | V7 | V8 | V9 | X2 | Stop | Change | X4 | Joker
type carte = couleur*valeur

                       (*exo5*)
let cube = fun a -> a *. a *. a
let intPositif = fun a -> if(a<0) then false else true
let pair = fun a -> if((a+1)/2 == a/2) then true else false
let signe = fun a-> if(a < 0) then -1 else (if a == 0 then 0 else 1)
let test = cube 2.0
let test = intPositif (-2)
let test = pair 2
let test = signe (0)

(*exo6*)
let f1 = fun a -> fun b -> fun c -> a*b*c
let f2 = fun a -> fun b -> fun c -> a+b+c
let testf1 = f1 1 2 3
let testf2 = f2 1 2 4

                (*exo7*)
let carre = fun a -> a*a
let triplet = fun a-> fun b->fun c -> if(carre(a) + carre(b) == carre(c) ||carre(c) + carre(b) == carre(a) ||carre(c) + carre(a) == carre(b))
                                      then true else false
let test = triplet 4 5 3;;
let memeSigne = fun a -> fun b -> if(signe a == signe b) then true else false
let test = memeSigne 0 1

                     (*exo9*)
let min2 = fun a -> fun b -> if(b>a) then a else b
let test = min2 1 2

(*exo10*)
let min3 = fun a -> fun b -> fun c -> min2 (min2 a b) c
let test = min3 4 8 3

                (*exo11*)
type point2D = int*int
type segment = point2D*point2D
let milieu = fun (s: segment):point2D -> let (p1,p2) = s in let (x1,y1) = p1 in let (x2,y2) = p2 in ((x1+x2)/2,(y1+y2)/2)
let s:segment = (0,0),(2,2)
let test = milieu s
let surSeg = fun s:segment -> p:point2D -> let (p1,p2) = s in let (x1,y2) = p1 in let (x2,y2) = p2 in let (x,y) = p in (x2-x1)*(y-y1)-(y2-y1)*(x-x1)==0;;
(*exo12*)
type semaine = Lundi | Mardi | Mercredi | Jeudi | Vendredi | Samedi | Dimanche;;
let weekend = fun (jour: semaine) -> if (jour == Samedi) || (jour == Dimanche) then true else false;;
let j: semaine = Samedi;;
let test = weekend j;;

(*exo13*)
type point2D =  float*float;;
type segment = point2D*point2D;;
type figure = Carre of(segment) | Rectangle of (segment*segment) | Cercle of (segment);;
let carre2 = fun a: float -> a*.a;;
let distance = fun (s : segment) -> let (p1,p2) = s in let (x1,y1) = p1 in let (x2,y2) = p2 in sqrt(carre2(x2-.x1)+.carre2(y2-.y1));;
let o = (1.,1.);;
let p = (1.,3.);;
let q = (1.,6.);;
let aireCarre = fun (f: segment) ->  carre2 (distance f)
let aireRect = fun (s1 : segment) -> fun (s2: segment) -> ((distance s1) *. (distance s2)) ;;
let aireCercle = fun (f:segment) ->  (carre2 (distance f)) *. 3.14;;
let testCarre= aireCarre (o,p);;
let testRect = aireRect (o,p) (o,q);;
let testCercle = aireCercle (o,p);;
let aire = fun f-> match f with | Carre (f) -> aireCarre f| Rectangle (f) ->let ((p1,p2),(p3,p4)) = f in aireRect (p1,p2) (p3,p4) | Cercle (f) -> aireCercle f;;
let figtest = Carre(o,p);;
let testAire= aire figtest;;

(*exo14*)
type couleur = Rouge| Vert | Jaune | Bleu | Neutre;;
type valeur = V0 | V1 | V2 | V3 | V4 | V5 | V6 | V7 | V8 | V9 | X2 | Stop | Change | X4 | Joker;;
type carte = couleur*valeur;;

let valNumb = fun (v : valeur) ->  match v with | V0 ->10 | V1 ->1 | V2 ->2 | V3 -> 3 | V4 ->4 | V5 -> 5 | V6 -> 6 | V7 -> 7 | V8 -> 8 | V9 -> 9 | X2 -> 20 | Stop -> 20 | Change -> 20 | Joker -> 50 | X4 ->50;;

let nextMove = fun (v :valeur) -> if ( v == Stop || v == Change) then false else true;;
let sameColor = fun (lastcolor : couleur) -> fun (nextcolor : couleur) -> if(( (lastcolor == nextcolor) || (lastcolor == Neutre) || (nextcolor == Neutre))) then true else false;;
                                                                                                                                                      let sameCard = fun (lastvalue: valeur) -> fun (nextvalue : valeur) -> if( ( (nextMove lastvalue) == true) && lastvalue == nextvalue) then true else false;;
let canplay = fun (lastcard: carte) -> fun (nextcard: carte) -> let (cl,vl) = lastcard in let (cn,vn) = nextcard in  if( ( ((sameColor cl cn) == true)&& (nextMove vl == true)) || sameCard vl vn )then true else false;; 

let card1 = (Bleu,X2);;
let card2 = (Rouge,V7);;
let testCard = canplay card1 card2;;

(*exo15*)
type listesint = | Nil  | Cons of int *listesint;;
let rec (longueur: listesint -> int) = fun a -> match a with |Nil -> 0 | Cons(_,t) -> 1+longueur t;;
let liste1 = Cons(1,(Cons(2,Cons(3,Nil))));;
let lg1 = longueur liste1;;

let rec (sumlist: listesint -> int) = fun a->  match a with
  | Nil-> 0
  | Cons(x,t) -> x+ sumlist t;;
let sumtest = sumlist liste1;;

let rec (isBool: listesint -> bool) = fun a->  match a with
  | Nil-> true
  | Cons(x,t) -> if x < 0 then false else isBool t;;
let isBooltest = isBool liste1;;

let rec addEnd = fun (l:listesint) (e:int): listesint ->  match l with
  | Nil->  Cons(e,Nil)
  | Cons(x,t) -> Cons(x,addEnd t e);;
let addEndtest = addEnd liste1 4;;

let rec concat = fun (l:listesint) (e:listesint): listesint ->  match l with
  | Nil->  e
  | Cons(x,t) -> Cons(x,concat t e);;
let addConcat = concat liste1 liste1;;


(*exo 15 suite*)
let rec (sumlist2: 'a list -> int) = fun a->  match a with
 | []-> 0
 | x::t -> x + sumlist2 t;;
let sumtest2 = sumlist2 liste1;;

let rec (isBool2: 'a list -> bool) = fun a->  match a with
  | []-> true
  | x::t -> if x < 0 then false else isBool2 t;;
let isBooltest2 = isBool liste1;;

let rec addEnd = fun (l:'a list) (e:int): 'a list->  match l with
  | []-> e::[]
  | x::t -> x::addEnd t e);;
let addEndtest2 = addEnd liste1 4;;

let rec concat2 = fun (l:'a list) (e:'a list): 'a list ->  match l with
  | []-> e
  | x::t -> x::concat2 t e;;
let addConcat2 = concat2 liste1 liste1;;



