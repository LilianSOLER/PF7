(*chapitre2*)
(*exo17*)
type contenu = | Meuble | Objet | Cadre| Plante;;
type solidite = |Fragile |Robuste |Resistant;;
type paquet = contenu*solidite*int;;

let p1 = (Meuble, Fragile, 5);;
let p2 = (Objet, Robuste, 25);;
let p3 = (Plante, Fragile, 2);;
let p4 = (Cadre, Resistant,15);;
let p5 = (Plante, Resistant, 26);;
let p6 = (Objet, Robuste, 18);;
let p7 = (Cadre, Robuste,20);;
let inv1 = [p1;p2;p3;p4;p5;p6;p7];;

(*exo18*)
let rec fragiles = fun (l:'a list): int ->  match l with
  | []->  0
  | x::t -> let (c,s,p) = x in( if (s == Fragile) then 1+ fragiles t else fragiles t) ;;
fragiles inv1;;

(*exo19*)
let rec legers = fun (inventaire:'a list) (poids: int) :'a list -> match inventaire with
                                                             | [] -> []
                                                             | paquet::l -> let (c,s,p) = paquet in (if (p<= poids) then paquet::legers l poids  else legers l poids) ;;
legers inv1 5;;
(*exo20*)

let rec poidsplantes = fun (l:'a list): int ->  match l with
  | []-> 0
  | (c,s,p)::t -> if (c == Plante) then (p + poidsplantes t) else poidsplantes t ;;
poidsplantes inv1;;

(*exo21*)
let rec exposition = fun (inventaire:'a list) :'a list -> match inventaire with
                                                             | [] -> []
                                                             | paquet::l -> let (c,s,p) = paquet in (if (c != Cadre) then paquet::exposition l else exposition l) ;;
exposition inv1;;

(*exo22*)


let rec inventorie = fun (inventaire:'a list) (paq:paquet): 'a list->
  match inventaire with
  |[] -> [paq]
  |current::l ->let (s,c,p) =current in (let (s1,c1,p1) = paq in
    (if (p>=p1) then paq::current::l else current::(inventorie l paq)));;
let p8 = (Meuble,Fragile,17);;
let inv2=[p3;p1;p4;p6;p7;p2;p5];;
inventorie inv2 p8;;

(*exo23*)
let rec dodromadaire = fun (inventaire : 'a list) (paq:paquet): paquet -> match inventaire with
  | [] -> paq
  | paquet::l -> let (c,s,p) = paquet in  let (c2,s2,p2) = paq in (if p2 >p then dodromadaire l paq else dodromadaire l paquet);; 

let dromadaire = fun (inventaire : 'a list): paquet -> match inventaire with
  | [] -> (Meuble, Robuste,-1)
  | (c,s,p) ::l -> dodromadaire l (c,s,p) ;;

dromadaire inv2;;

(*Chez Tardy*)
(*exo25*)
type produit = | MP3 | Photo | Camera | Tel | Ordi;;
type marque = | Alpel | Syno | Massung | Liphisp;;
type article = produit*marque*int*int;;

let art1 = (MP3,Alpel,54,5);;
let art2 = (MP3,Syno,32,16);;
let art3 = (Camera,Liphisp,118,7);;
let art4 = (Camera,Massung,89,19);;
let art5 = (Tel,Massung,489,45);;
let art6 = (Tel,Alpel,777,77);;
let art7 = (Ordi,Alpel,1329,32);;
let prodtest = Ordi;;
let marqtest = Syno;;
let prixtest = 500;;
let artTest= (prodtest,marqtest, prixtest,1);;
let inv1 = [art1; art2; art3; art4; art5; art6; art7];;
(*exo26*)
let meme_article = fun (p : produit) (m : marque) (prix : int) (art : article): bool ->  let (p2,m2,prix2,s2) =art in (if(p==p2 && m==m2 && prix == prix2 && s2 >0) then true else false);;

let rec est_en_stock = fun (p: produit)(m: marque)(prix:int)(inventaire:'a list): bool-> match inventaire with
                                                                  | []-> false
                                                                  |current::next -> if (meme_article p m prix current) == true then true else est_en_stock p m prix next;;

est_en_stock prodtest marqtest prixtest inv1;;
est_en_stock MP3 Alpel 54 inv1;;

(*exo27*)
(*fonction rebuild "reconstruit" la liste*)
let rec rebuild = fun liste -> match liste with
                            |[] -> []
                            |current::next -> current::rebuild next;;

let rec concat = fun l1 -> fun l2 -> match l1 with
                                      |[] -> rebuild l2
                                      |current::next -> current::concat next l2;;

let rec ajoute_article = fun (art:article)(inventaire:'a list) :'a list-> match inventaire with
   |[]-> art::[]
   |current::next-> let (p, m, prix, s) = art in (if (meme_article p m prix current) then let (p2,m2,prix2,s2) = current in (p,m,prix,s +s2)::next else current::ajoute_article art next) ;;

ajoute_article artTest inv1;;
ajoute_article art1 inv1;;

(*exo 28*)
let rec enleve_article = fun (art:article)(inventaire:'a list) :'a list-> match inventaire with
   |[]-> []
   |current::next-> let (p, m, prix, s) = art in (if (meme_article p m prix current) then next else current::enleve_article art next) ;;

enleve_article artTest inv1;;
enleve_article art7 inv1;;

(*exo 34*)
let rec trouve_min = fun (art:article)(inventaire:'a list) :'a list-> match inventaire with
   |[]-> []
   |current::next-> let (p, m, prix, s) = art in (if (meme_article p m prix current) then next else current::trouve_min art next) ;;
