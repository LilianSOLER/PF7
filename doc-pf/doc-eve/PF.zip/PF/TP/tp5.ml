*(* Analyse descendante récursive sur une liste *)
(*
 S ::= (S) | x
*)

exception Echec
type analist = char list -> char list

(* Consommation d'un caractère précis en début de mot *)
let p_parouv : analist = fun l -> match l with
  | '(' :: l -> l
  | _ -> raise Echec

let p_parfer : analist = fun l -> match l with
  | ')' :: l -> l
  | _ -> raise Echec

let p_x : analist = fun l -> match l with
  | 'x' :: l -> l
  | _ -> raise Echec

(* Généralisation *)
let terminal c : analist = fun l -> match l with
  | x :: l when x = c -> l
  | _ -> raise Echec


(* On vise la grammaire suivante :
  S ::= '(' S ')'
  S ::= 'x'

  On considère d'abord une grammaire non récursive, en séparant les règles
    S0 :: 'x'
    S1 ::= '(' S0 ')'
    S2 ::= 'x'
    S  ::= S1 | S2
*)

let p_S0 : analist = terminal 'x'

let p_S1 : analist = fun l ->
  let l1 = terminal '(' l in
  let l2 = p_S0 l1 in
  let l3 = terminal ')' l2 in
  l3

(* écriture moins gourmande en identificateurs *)
let p_S1 : analist = fun l ->
  let l = terminal '(' l in
  let l = p_S0 l in
  let l = terminal ')' l in
  l

let p_S2 : analist = terminal 'x'

let p_S : analist = fun l ->
  try p_S1 l with Echec -> p_S2 l

(* Tests *)

let list_of_string s =
  let rec boucle s i n =
    if i = n then [] else s.[i] :: boucle s (i+1) n
  in boucle s 0 (String.length s)

let ch1 = list_of_string "(x)()abc"
let _ = p_S ch1
let ch2 = list_of_string "x()abc"
let _ = p_S ch2
let ch3 = list_of_string "()()abc"
let _ = p_S ch3

(* Grammaire récursive
    S1 ::= '(' S ')'
    S2 ::= 'x'
    S  ::= S1 | S2
*)

let rec p_S : analist =
  let p_S1 : analist = fun l ->
    let l = terminal '(' l in
    let l = p_S l in
    let l = terminal ')' l in
    l
  and p_S2 : analist = fun l ->
    let l = terminal 'x' l in
    l in
  fun l ->
  try p_S1 l with Echec -> p_S2 l

let ch1 = list_of_string "(((x)))abc"
let _ = p_S ch1
let ch2 = list_of_string "x()abc"
let _ = p_S ch2
let ch3 = list_of_string "()()abc"
let _ = p_S ch3

(* Grammaire récursive avec calcul d'AST *)
type ast = Fin | Pa of ast
type 'a canalist = char list -> 'a * char list

let rec p_S : ast canalist =
  let p_S1 : ast canalist = fun l ->
    let l = terminal '(' l in
    let a, l = p_S l in
    let l = terminal ')' l in
    Pa (a), l
  and p_S2 : ast canalist = fun l ->
    let l = terminal 'x' l in
    Fin, l
  in fun l ->
     try p_S1 l with
       Echec -> p_S2 l

let ch1 = list_of_string "(((x)))a(bc"
let _ = p_S ch1
let ch2 = list_of_string "x()abc"
let _ = p_S ch2
let ch3 = list_of_string "()()abc"
let _ = p_S ch3


(* ------------------------------------------------------------ *)

(* Les grammaires comportent souvent de la récursion mutuelle
   voici un exemple pour illustrer la syntaxe à employer en OCaml.

  B ::= (B) | C
  C ::= x   | yC  | zBC

(Sans détailler la décomposition de S en S1 et S2,
et celle de L en L1, L2 et L3)

 *)

type boite = Emb of boite | Cont of contenu
and contenu = X | Y of contenu | Z of boite * contenu

let rec p_B : boite canalist =
  let p_B1 : boite canalist = fun l ->
    let l = terminal '(' l in
    let b, l = p_B l in
    let l = terminal ')' l in
    Emb (b), l
  and p_B2 : boite canalist = fun l ->
    let c, l = p_C l in
    Cont (c), l
  in fun l ->
     try p_B1 l with
       Echec -> p_B2 l

and p_C : contenu canalist =
  let p_C1 : contenu canalist = fun l ->
    let l = terminal 'x' l in
    X, l
  and p_C2 : contenu canalist = fun l ->
    let l = terminal 'y' l in
    let c, l = p_C l in
    Y (c), l
  and p_C3 : contenu canalist = fun l ->
    let l = terminal 'z' l in
    let b, l = p_B l in
    let c, l = p_C l in
    Z (b, c), l
  in fun l ->
     try p_C1 l with
       Echec ->
       try p_C2 l with
         Echec ->
          p_C3 l
    

let ch1 = list_of_string "((yz(yyx)yx))a"
let _ = p_B ch1

(* ------------------------------------------------------------ *)
(* Combinateurs d'analyseurs
   (facultatif pour l'instant : sans calcul d'AST) *)
(* ------------------------------------------------------------ *)

(* a suivi de b *)
let (+>) (a : analist) (b : analist) : analist =
  fun l -> b (a l)

(* choix entre a ou b *)
let (+|) (a : analist) (b : analist) : analist =
  fun l -> try a l with Echec -> b l

(* Redéfinition des précédents de façon plus compacte *)
let p_S0 : analist = terminal 'x'

let p_S1 : analist =
  terminal '(' +> p_S0 +> terminal ')'

let p_S2 : analist = terminal 'x'

let p_S : analist = p_S1 +| p_S2

(* Tests *)

let ch1 = list_of_string "(x)abc"
let _ = p_S ch1
let ch2 = list_of_string "xabc"
let _ = p_S ch2
let ch3 = list_of_string "()abc"
let _ = p_S ch3


(* La grammaire récursive  S ::= '(' S ')'  |  'x'
   se définit alors ainsi avec les combinateurs.
   Le let rec impose l'explicitation d'au moins un argument,
   d'où l'encadrement "fun l -> ("   ...    ") l"
*)

let rec p_S : analist =
  fun l -> (
              (terminal '(' +> p_S +> terminal ')')
           +|
              (terminal 'x')
  )  l

let rec p_S =
  let p_S1 l = (terminal '(' +> p_S +> terminal ')') l
  and p_S2 = terminal 'x'
  in fun l -> (p_S1 +| p_S2) l

let rec p_S =
  let p_S2 = terminal 'x'
  and p_S1 l = (terminal '(' +> p_S +> terminal ')') l
  in fun l -> (p_S1 +| p_S2) l

(* Tests *)

let ch1 = list_of_string "(((x)))abc"
let _ = p_S ch1
let ch2 = list_of_string "xabc"
let _ = p_S ch2
let ch3 = list_of_string "(x)abc"
let _ = p_S ch3
let ch3 = list_of_string "((x))abc"
let _ = p_S ch3
let ch4 = list_of_string "()abc"
let _ = p_S ch4
