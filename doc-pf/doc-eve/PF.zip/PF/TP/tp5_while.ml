exception ParserException;;
(*
  V ::= a | b | c | d
  C ::= 0 | 1
  E ::= V | C
  I ::= I;I | V:=E | i.E{I}{I} | w.E{I} | ε
*)
let p_var (l: char list) : char list =
  match l  with
  | 'a'::l' -> l'
  | 'b'::l' -> l'
  | 'c'::l' -> l'
  | 'd'::l' -> l'
  | _ -> raise ParserException;;
                                          
let p_cons (l: char list) : char list = match l with
  | '0' :: l' -> l'
  | '1' :: l' -> l'
  | _ -> raise ParserException;;

(*char speciaux *)
let p_spec c  (l: char list) : char list = match l with
  | x :: l' when x = c -> l'
  | _ -> raise ParserException;;

(*E ::= V | C*)
let p_exp (l: char list) : char list =
  try p_var l with ParserException ->  p_cons l ;;

(*V:=E*)
let rec affectation (l: char list): char list =
   let l = try p_var l with ParserException -> raise ParserException in
   let l = try p_spec ':' l with ParserException -> raise ParserException in
   let l = try p_spec '=' l with ParserException -> raise ParserException in
   let l = try p_exp l  with ParserException -> raise ParserException in
   let l = try p_spec ';' l with ParserException -> raise ParserException in l;;


(* I ::= I;I | V:=E | i.E{I}{I} | w.E{I} | ε*)

let rec p_instr (l: char list): char list = match l with
  | [] -> []
  | '}'::l' -> l
  | 'i'::l' -> let l = try p_instr (p_if l)  with ParserException -> raise ParserException in l
  | 'w'::l' -> let l = try p_instr (p_while l)  with ParserException -> raise ParserException in l
  |  _::l' -> let l = try p_instr (affectation l) with ParserException -> raise ParserException in l
 (* | _  -> try p_instr (affectation l) with ParserException ->
    try p_instr (sub_instr l)  with ParserException ->
      try p_instr (p_if l)  with ParserException ->
        try p_instr (p_while l) with ParserException -> raise ParserException*)

(* I;I ---------> ATTENTION I;I ----> REVIENT A EFFECTUER RECURSION. MAIS INUTILE SI APPEL RECURSIF DE P_INSTR. Y a plusieurs methodes ;) *)
(*and sub_instr (l: char list): char list =
      let l = try p_instr l with ParserException -> raise ParserException in
      let l = try p_spec ';' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in l*)

(*i(exp){I}{I}*) 
and p_if (l: char list): char list = 
      let l = try p_spec 'i' l with ParserException -> raise ParserException in
      let l = try p_spec '(' l with ParserException -> raise ParserException in
      let l = try p_exp l with ParserException -> raise ParserException in
      let l = try p_spec ')' l with ParserException -> raise ParserException in
      let l = try p_spec '{' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in
      let l = try p_spec '}' l with ParserException -> raise ParserException in
      let l = try p_spec '{' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in 
      let l = try p_spec '}' l with ParserException -> raise ParserException in l
 (*w(exp){I}*)
and p_while (l: char list): char list =
      let l = try p_spec 'w' l with ParserException -> raise ParserException in
      let l = try p_spec '(' l with ParserException -> raise ParserException in
      let l = try p_exp l with ParserException -> raise ParserException in
      let l = try p_spec ')' l with ParserException -> raise ParserException in
      let l = try p_spec '{' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in
      let l = try p_spec '}' l with ParserException -> raise ParserException in l

let list_of_string s =
  let rec boucle s i n =
    if i = n then [] else s.[i] :: boucle s (i+1) n
  in boucle s 0 (String.length s);;


let parser = fun s ->
  let ls=list_of_string s in let res= try p_instr ls with ParserException -> '-'::[] in
                             if(res=[])then true else false;;

let s1="test";;
let s2="a:=1;b:=1;c:=1;w(a){i(c){c:=0;a:=b;}{b:=0;c:=a;}}";;
let s3="w(b){a:=0;}";;
let s4="i(a){a:=1;}{a:=0;}";;
let s5="a:=1;b:=0;";;
let s6="a:=1;b:=0;w(b){a:=0;}";;
let s7="a:=0;b:=1;c:=0;i(c){c:=0;}{d:=0;}";;
let test = parser s7;;
