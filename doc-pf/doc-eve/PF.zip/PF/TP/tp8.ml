(* exercice 90 *)

exception FileException;;

type 'a file = 'a list;;


let rec file_vide :'a file = [];;

let rec file_est_vide (f: 'a file) : bool = match f with
  | [] -> true
  | _ -> false;;

let enfile (elem : 'a) (f: 'a file) : 'a file  = elem::f;;

let rec defile  (f: 'a file) : ('a * 'a file)  = match f with
  | [] -> raise FileException
  | x::[] -> (x,[])
  | x::f' -> let (y,file) =  defile f' in (y,x::file) ;;

(*liste -> file*)
let rec enfileListe (l : 'a list) (f : 'a list) : 'a list = match l with
  | [] -> f
  | x::l' -> enfileListe l' (enfile x f);;

(* file -> liste*)
let rec listeDefile (f : 'a list): 'a list =
 match f with
  |[] -> []
  |x::fi -> let (x,fi)=defile f in x::(listeDefile fi);;


let l1 = 1::2::3::4::[];;
let l2 = enfileListe l1 file_vide;;

let l3 = listeDefile (l2);;

let rec testliste (l1 : 'a list) (l2 : 'a list): bool =
  match l1,l2 with
  | [], [] -> true
  | [], r::r' -> false
  | l::l', [] -> false
  | r::r', l::l'  -> if (r = l) then (testliste r' l') else true;;
  
let rec teste_file (l : 'a list) : bool =
  let ldeb = enfileListe l file_vide in
  let lfin = listeDefile ldeb in
  testliste ldeb lfin;;

teste_file l2;;

(*exercice 92*)
type 'a file2 = 'a list * 'a list;;



let rec file_vide2 :'a file2 = ([],[]);;

let rec file_est_vide2 (f: 'a file2) : bool = match f with
  | [], [] -> true
  | _,_ -> false;;

let enfile2 (elem : 'a) (f: 'a file2) : 'a file2 = let (inL, outL) = f in elem::inL, outL;;

let rec transfert (l1 : 'a list) (l2 : 'a list) : 'a list = match l1 with
  | [] -> l2
  | x::l' -> transfert l' (x::l2);;

let l3 = 1::2::3::4::5::[];;
transfert l3 [];;

let rec defile2  (f: 'a file2) : ('a * 'a file2)  = match f with
  | [], [] ->raise FileException
  | _, [] -> let (l1,l2) = f in (defile2 ([],transfert l1 l2))
  | l1, x::l2 -> (x,(l1,l2));;
