(* EX 66 *)

type abin =
  | V
  | N of abin * int * abin;;

let av = V;;
let a1 = N(V, 5, V);;
let a2 = N(V, 3, N(V, 10, V));;
let a3 = N(N(V, 10, V), 3, V);;
let a4 = N(N(V, 10, V), 3, N(V, 5, V));;

let rec noeuds = fun a -> match a with
                          | V -> 0
                          | N (g, x, d) -> 1 + noeuds g + noeuds d;;

let max = fun a b -> if (a >= b) then a else b;;

let rec hauteur = fun a -> match a with
                           | V -> -1
                           | N(g, x, d) -> 1 + max (hauteur g) (hauteur d);;

let rec hauteur2 = fun a -> match a with
                           | V -> -1
                           | N(g, x, d) -> (let mg = (hauteur g) and md = (hauteur d) in
                                            if (mg >= md) then mg else md) + 1;;

let rec produit = fun a -> match a with
                           | V -> 1
                           | N(g, x, d) -> (produit g) * x * (produit d);;

let rec somme = fun a -> match a with
                         | V -> 0
                         | N(g, x, d) -> (somme g) + x + (somme d);;

let rec prodsom = fun a -> match a with
                          | V -> (1, 0)
                          | N(g, x, d) -> let (p1, s1) = prodsom g and (p2, s2) = prodsom d in
                                          (p1 * x * p2, s1 + x + s2);;

let rec appartient = fun a x -> match a with
                              | V -> false
                              | N(g, elem, d) -> (appartient g x) || x = elem || (appartient d x);;

let rec maximum = fun a -> match a with
                           | V -> 0
                           | N(g, x, d) -> max x (max (maximum g) (maximum d));;

let rec vraies = fun a -> match a with
                          | V -> 0;
                          | N(V, _, d) -> vraies d
                          | N(g, _, V) -> vraies g
                          | N(g, _, d) -> vraies g + 1 + vraies d;;

(* EX 47
1. a. [x = 5, y = 8, x = 7]
   b. [a = 5, f = fun x -> x + 5, a = 10, y = 15]
   c. [a = 5, f = fun x -> x + 5, a = 6, y = 11]
2. let y = x + 1      5. 101
3. let y = x > 1      5. true
4. let y = x = 1      5. false


   EX 48
1. oui, 3
2. non, a est defini dans la fonction f
3. oui, 3
4. non, f non defini
5. oui
*)

(* EX 62 *)
exception PasElement;;

let rec trouve = fun (p : int -> bool) l -> match l with
                                            | [] -> raise PasElement   (* failwith "PasElement" *)
                                            | x::s -> if (p x) then x else trouve p s;;
