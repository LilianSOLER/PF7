(*

let r = let x = 7 in 6 * x;;

let a = (r - 6) / 6 - 6;;

let o = r * r - x * x - 51;;

let u = let x = 9 in if (x < 9) then 9 / (x - x) else (x + x) / 9;;

let pisur4 = 3.14 /. 4.;;

let danslordre = (1 < 2) && (2 < 3);;

let positif = let a = 42 in if a >= 0 then true else false;;

let doubleabsolu = let x = -2.7 in (if (x < 0.) then x else -.x) *. -.2.;;

type semaine = Lundi | Mardi | Mercredi | Jeudi | Vendredi | Samedi | Dimanche;;

type point2D = P of float * float;;

let origine = P(0., 0.);;

type segment = S of point2D * point2D;;

type figure =
  | Carre of segment * segment * segment * segment
  | Rectangle of segment * segment * segment * segment
  | Cercle of point2D * segment


let c = Carre((P(0.,0.), P(0., 1.)), (P(0., 1.), P(1., 1.)), (P(1., 1.), P(1., 0.)), (P(1., 0.), P(0., 0.)));;

let r = Rectangle((P(0.,0.), P(0., 1.)), (P(0., 1.), P(1., 1.)), (P(1., 1.), P(1., 0.)), (P(1., 0.), P(0., 0.)));;

let c = Cercle(P(0.,0.), (P(0.,0.), P(0.,1.)));;


type chiffre = Zero | Un | Deux | Trois | Quatre | Cinq | Six | Sept | Huit | Neuf;;

type couleur = Rouge | Vert | Jaune | Bleu | Multi;;

type special = P2 | P4 | Inv | Passe | Joker;;

type carteUno =
  | Normal of chiffre * couleur
  | Special of special * couleur;;

type pile = P of carteUno;;


let cube = fun a -> a *. a *. a;;

let positif = fun a -> a > 0;;

let pair = fun a -> a mod 2 = 0;;

let signe = fun a ->
  if a < 0 then -1 else
    if a > 0 then +1 else 0;;

let f1 = fun a -> fun b -> fun c -> a * b * c;;

let f2 = fun a -> fun b -> fun c -> a + b + c;;

let pythagore = fun a -> fun b -> fun c -> if a * a + b * b = c * c then true else false;;

let meme_signe = fun a -> fun b -> signe(a) = signe(b);;

let min2entiers = fun a -> fun b -> if a < b then a else b;;

let min3entiers = fun a -> fun b -> fun c -> let min = min2entiers a b in min2entiers min c;;

let milieu = fun a -> let S(c,d) = a in let P(p1x, p1y) = c in let P(p2x, p2y) = d in P((p1x +. p2x) /. 2., (p1y +. p2y) /. 2.);;

let appartient = fun a -> fun b -> let S(P(p1x, p1y), P(p2x, p2y)) = a in let P(t1x, t1y) = b in sqrt( (p2x -. p1x) ** 2. +. (p2y -. p1y) ** 2. ) = sqrt( (t1x -. p1x) ** 2. +. (t1y -. p1y) ** 2. ) +. sqrt( (p2x -. t1x) ** 2. +. (p2y -. t1y) ** 2. );;

appartient (S(P(0.,0.), P(1.,1.))) (P(0.5, 0.5));;

let weekend = fun j -> j = Samedi || j = Dimanche;;

let aire = fun f -> match f with
                    | Carre(S(P(x1,y1),P(x2,y2)), _, _, _) -> (x2 -. x1) *. (x2 -. x1) +. (y2 -. y1) *. (y2 -. y1)
                    | Rectangle(S(P(x1,y1),P(x2,y2)), S(P(x1b,y1b),P(x2b,y2b)), _, _) -> sqrt( (x2 -. x1) *. (x2 -. x1) +. (y2 -. y1) *. (y2 -. y1) ) *. sqrt( (x2b -. x1b) *. (x2b -. x1b) +. (y2b -. y1b) *. (y2b -. y1b) )
                    | Cercle(_, S(P(x1,y1),P(x2,y2))) -> 3.14 *. ((x2 -. x1) *. (x2 -. x1) +. (y2 -. y1) *. (y2 -. y1));;

let digit = fun d -> match d with
                     | Zero -> 0
                     | Un -> 1
                     | Deux -> 2
                     | Trois -> 3
                     | Quatre -> 4
                     | Cinq -> 5
                     | Six -> 6
                     | Sept -> 7
                     | Huit -> 8
                     | Neuf -> 9;;

let spe = fun d -> match d with
                   | Inv
                     | Passe
                     | P2 -> 20
                   | P4
                     | Joker -> 50;;

let valeur = fun card -> match card with
                          | Normal(t, c) -> digit(t)
                          | Special(t, c) -> spe(t);;

let joueurSuivant = fun card -> match card with
                                | Normal(t, c) -> true
                                | Special(t, c) -> t = Joker;;

let peutPoser = fun card -> fun pile -> let P(c) = pile in
                                        match card with
                                        | Normal(chiffreC, couleurC) -> begin match c with
                                                                        | Normal(chiffreP, couleurP) -> chiffreC = chiffreP || couleurC = couleurP
                                                                        | Special(typeP, couleurP) -> couleurC = couleurP || couleurP = Multi end
                                        | Special(typeC, couleurC) -> begin match c with
                                                                        | Normal(chiffreP, couleurP) -> couleurC = couleurP || typeC = P4 || typeC = Joker
                                                                        | Special(typeP, couleurP) -> typeC = typeP || typeC = P4 || typeC = Joker end;;

type chiffreNormal = Un | Deux | Trois | Quatre | Cinq | Six | Sept | Huit | Neuf | Dix | Valet | Dame | Roi | Joker;;

type couleurNormal = Carreau | Coeur | Trefle | Pique;;

type carteNormal = CN of chiffreNormal * couleurNormal;;

let couleurNormalUno = fun normal -> match normal with
                                     | Carreau -> Rouge
                                     | Coeur -> Vert
                                     | Trefle -> Jaune
                                     | Pique -> Bleu;;

let chiffreNormalUno = fun normal -> match normal with
                                     | CN(Un, c) -> begin match c with
                                                    | Carreau
                                                      | Coeur ->  Normal(Zero, couleurNormalUno(c))
                                                    | Trefle
                                                      | Pique -> Special(P4, Multi) end
                                     | CN(Deux, c) -> Normal(Un, couleurNormalUno(c))
                                     | CN(Trois, c) -> Normal(Deux, couleurNormalUno(c))
                                     | CN(Quatre, c) -> Normal(Trois, couleurNormalUno(c))
                                     | CN(Cinq, c) -> Normal(Quatre, couleurNormalUno(c))
                                     | CN(Six, c) -> Normal(Cinq, couleurNormalUno(c))
                                     | CN(Sept, c) -> Normal(Six, couleurNormalUno(c))
                                     | CN(Huit, c) -> Normal(Sept, couleurNormalUno(c))
                                     | CN(Neuf, c) -> Normal(Huit, couleurNormalUno(c))
                                     | CN(Dix, c) -> Normal(Neuf, couleurNormalUno(c))
                                     | CN(Valet, c) -> Special(P2, couleurNormalUno(c))
                                     | CN(Dame, c) -> Special(Inv, couleurNormalUno(c))
                                     | CN(Roi, c) -> Special(Passe, couleurNormalUno(c))
                                     | CN(Joker, _) -> Special(Joker, Multi);;

 *)

type listent = Nil | Cons of int * listent;;

let rec somme = fun l -> match l with
                         | Nil -> 0
                         | Cons(x, s) -> x + somme s;;

let rec sommeOcaml = fun l -> match l with
                              | [] -> 0
                              | x::s -> x + sommeOcaml s;;

let rec positif = fun l -> match l with
                           | Nil -> true
                           | Cons(x, s) -> x >= 0 && positif s;;

let rec positifOcaml = fun l -> match l with
                                | [] -> true
                                | x::s -> x >= 0 && positifOcaml s;;

let rec ajout = fun (l, elem):listent -> match l with
                                         | Nil -> Cons(elem, Nil)
                                         | Cons(x, s) -> Cons(x, ajout(s, elem));;

let rec ajoutOcaml = fun (l, elem) -> match l with
                                         | [] -> elem::[]
                                         | x::s -> x::ajoutOcaml(s, elem);;

let rec concaten = fun (l1, l2) -> match l1 with
                                       | Nil -> l2
                                       | Cons(x, Nil) -> Cons(x, l2)
                                       | Cons(x, s) -> Cons(x, concaten(s, l2));;

let rec concatenOcaml = fun (l1, l2) -> match l1 with
                                        | [] -> l2
                                        | x::[] -> x::l2
                                        | x::s -> x::concatenOcaml(s, l2);;

let rec affiche = fun l -> match l with
                           | Nil -> ()
                           | Cons(x, s) -> print_int x; print_string " "; affiche s;;

let list1 = Cons(1, Cons(2, Cons(3, Cons(4, Nil))));;

let list2 = Cons(5, Cons(6, Cons(7, Cons(8, Nil))));;

let list1Ocaml = 1::2::3::4::[];;

let list2Ocaml = 5::6::7::8::[];;

concatenOcaml (list1Ocaml, list2Ocaml);;
