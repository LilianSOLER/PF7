(*
    Lucas DREZET : lucasdrezet@gmail.com
    Sami ELHADJI-TCHIAMBOU : sami3232@live.fr
  
    tout a ete fait (pour la grammaire 1, renvoie un bool et pour la grammaire 2 renvoie ast*bool)
*)


(* Grammaire 1 :
  V ::= a | b | c | d
  C ::= 0 | 1
  E ::= V | C
  I ::= I;I | V:=E | i.E{I}{I} | w.E{I} | ε
*)

exception ParserException;;

let stringToList = fun s -> let rec boucle s i n = if i = n then [] else s.[i] :: boucle s (i+1) n
                            in boucle s 0 (String.length s);;

let p_var (l: char list) : char list =
  match l  with
  | 'a'::l' -> l'
  | 'b'::l' -> l'
  | 'c'::l' -> l'
  | 'd'::l' -> l'
  | _ -> raise ParserException;;
                                          
let p_cons (l: char list) : char list = match l with
  | '0' :: l' -> l'
  | '1' :: l' -> l'
  | _ -> raise ParserException;;

(*char speciaux *)
let p_spec c  (l: char list) : char list = match l with
  | x :: l' when x = c -> l'
  | _ -> raise ParserException;;

(*E ::= V | C*)
let p_exp (l: char list) : char list =
  try p_var l with ParserException ->  p_cons l ;;

(*V:=E*)
let rec affectation (l: char list): char list =
   let l = try p_var l with ParserException -> raise ParserException in
   let l = try p_spec ':' l with ParserException -> raise ParserException in
   let l = try p_spec '=' l with ParserException -> raise ParserException in
   let l = try p_exp l  with ParserException -> raise ParserException in
   let l = try p_spec ';' l with ParserException -> raise ParserException in l;;


(* I ::= I;I | V:=E | i.E{I}{I} | w.E{I} | ε*)

let rec p_instr (l: char list): char list = match l with
  | [] -> []
  | '}'::l' -> l
  | 'i'::l' -> let l = try p_instr (p_if l)  with ParserException -> raise ParserException in l
  | 'w'::l' -> let l = try p_instr (p_while l)  with ParserException -> raise ParserException in l
  |  _::l' -> let l = try p_instr (affectation l) with ParserException -> raise ParserException in l
 (* | _  -> try p_instr (affectation l) with ParserException ->
    try p_instr (sub_instr l)  with ParserException ->
      try p_instr (p_if l)  with ParserException ->
        try p_instr (p_while l) with ParserException -> raise ParserException*)

(* I;I ---------> ATTENTION I;I ----> REVIENT A EFFECTUER RECURSION. MAIS INUTILE SI APPEL RECURSIF DE P_INSTR. Y a plusieurs methodes ;) *)
(*and sub_instr (l: char list): char list =
      let l = try p_instr l with ParserException -> raise ParserException in
      let l = try p_spec ';' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in l*)

(*i(exp){I}{I}*) 
and p_if (l: char list): char list = 
      let l = try p_spec 'i' l with ParserException -> raise ParserException in
      let l = try p_spec '(' l with ParserException -> raise ParserException in
      let l = try p_exp l with ParserException -> raise ParserException in
      let l = try p_spec ')' l with ParserException -> raise ParserException in
      let l = try p_spec '{' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in
      let l = try p_spec '}' l with ParserException -> raise ParserException in
      let l = try p_spec '{' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in 
      let l = try p_spec '}' l with ParserException -> raise ParserException in l
 (*w(exp){I}*)
and p_while (l: char list): char list =
      let l = try p_spec 'w' l with ParserException -> raise ParserException in
      let l = try p_spec '(' l with ParserException -> raise ParserException in
      let l = try p_exp l with ParserException -> raise ParserException in
      let l = try p_spec ')' l with ParserException -> raise ParserException in
      let l = try p_spec '{' l with ParserException -> raise ParserException in
      let l = try p_instr l with ParserException -> raise ParserException in
      let l = try p_spec '}' l with ParserException -> raise ParserException in l

let parserG1 = fun s ->
  let ls=stringToList s in let res= try p_instr ls with ParserException -> '-'::[] in
                             if(res=[])then true else false;;

parserG1 "test";;
parserG1 "a:=1;b:=1;c:=1;w(a){i(c){c:=0;a:=b;}{b:=0;c:=a;}}";;
parserG1 "w(b){a:=0;}";;
parserG1 "i(a){a:=1;}{a:=0;}";;
parserG1 "a:=1;b:=0;";;
parserG1 "a:=1;b:=0;w(b){a:=0;}";;
parserG1 "a:=0;b:=1;c:=0;i(c){c:=0;}{d:=0;}";;




(* Grammaire 2 :
  V ::= a | b | c | d
  C ::= 0 | 1
  E ::= V | C
  S ::= IL | ε
  L ::= ;S | ε
  I ::= V:=E | i.E{S}{S} | w.E{S} | ε
 *)

type v =
  | A
  | B
  | C
  | D;;

type c =
  | Zero
  | Un;;

type e =
  | Variable of v
  | Constante of c;;

type s =
  | ListeInstruction of i * l
  | EpsilonS
and
l =
  | PS of s
  | EpsilonL
and
  i =
  | Affectation of v * e
  | If of e * s * s
  | While of e * s
  | EpsilonI;;

exception Echec;;


let lireCaractere = fun c -> fun l -> match l with
                                      | x::l when x = c -> l
                                      | _ -> raise Echec;;

let lireExpr = fun l -> match l with
                        | '0'::s -> Constante Zero, s
                        | '1'::s -> Constante Un, s
                        | 'a'::s -> Variable A, s
                        | 'b'::s -> Variable B, s
                        | 'c'::s -> Variable C, s
                        | 'd'::s -> Variable D, s
                        | _ -> raise Echec;;

let lireVar = fun l ->  match l with
                        | 'a'::s -> A, s
                        | 'b'::s -> B, s
                        | 'c'::s -> C, s
                        | 'd'::s -> D, s
                        | _ -> raise Echec;;

let rec pS = let pS1 = fun l -> let i, l = pI l in
                                let li, l = pL l in
                                ListeInstruction(i, li), l
               and
                 pE = fun l -> EpsilonS, l
             in
             fun l ->  try pS1 l with
                       | Echec -> pE l
  and
    pL = let pL1 = fun l -> let l = lireCaractere ';' l in
                            let s, l = pS l in
                            PS(s), l
           and
             pE = fun l -> EpsilonL, l
         in
         fun l ->  try pL1 l with
                   | Echec -> pE l
  and
    pI = let pIF = fun l -> let l = lireCaractere 'i' l in
                            let l = lireCaractere '(' l in
                            let e, l = lireExpr l in
                            let l = lireCaractere ')' l in
                            let l = lireCaractere '{' l in
                            let s1, l = pS l in
                            let l = lireCaractere '}' l  in
                            let l = lireCaractere '{' l in
                            let s2, l = pS l in
                            let l = lireCaractere '}' l in
                            If(e, s1, s2), l
           and
             pW = fun l -> let l = lireCaractere 'w' l in
                           let l = lireCaractere '(' l in
                           let e, l = lireExpr l in
                           let l = lireCaractere ')' l in
                           let l = lireCaractere '{' l in
                           let s, l = pS l in
                           let l = lireCaractere '}' l in
                           While(e, s), l
           and
             pA = fun l -> let v, l = lireVar l in
                           let l = lireCaractere ':' l in
                           let l = lireCaractere '=' l in
                           let e, l = lireExpr l in
                           Affectation(v, e), l
           and
             pE = fun l -> EpsilonI, l
         in
         fun l -> try pIF l with
                  | Echec -> try pW l with
                             | Echec -> try pA l with
                                        | Echec -> pE l;;

let parserG2 = fun s ->
  try
    let ast, res = pS (stringToList s) in
    match res with
    | [] -> ast, true
    | _ -> EpsilonS, false
  with
  | Echec -> EpsilonS, false;;


(* TEST *)
parserG2 ";";;
parserG2 "a";;
parserG2 "a:";;
parserG2 "a:=";;

parserG2 "a:=1";;
parserG2 "b:=0";;
parserG2 "c:=1;";;
parserG2 "d:=0;";;

parserG2 "i(d){;}{}";;
parserG2 "w(a){c:=0}";;
parserG2 "i(c){c:=0;a:=b}{b:=0;c:=a}";;

parserG2 "a:=1;b:=1;c:=1;w(a){i(c){c:=0;a:=b}{b:=0;c:=a}}";;
