(*
  Lucas DREZET : lucasdrezet@gmail.com
  Sami ELHADJI-TCHIAMBOU : sami3232@live.fr
  
  tout a ete fait
*)

exception ArbreVide;;
exception PasDansArbre;;
exception PasABR;;

Random.self_init();;


(* TP4 : DES ARBRES ET ENCORE DES ARBRES *)
(* 4.1. Arbres Binaires de Recherche *)
type abint =
  | Vide
  | Noeud of abint * int * abint;;

(* EX 40 *)
let exemple = Noeud(Noeud(Noeud(Vide, 2, Vide), 3, Vide), 5, Noeud(Noeud(Vide, 6, Noeud(Vide, 7, Vide)), 8, Noeud(Vide, 9, Vide)));;


(* EX 41 *)
let rec mem = fun a -> fun x -> match a with
                                | Vide -> false
                                | Noeud(g, v, d) -> if (v = x) then true
                                                    else if (x < v) then mem g x
                                                    else mem d x;; 

mem exemple 6;;
mem exemple 10;;

(* EX 42 *)
let rec insert = fun a -> fun x -> match a with
                                   | Vide -> Noeud(Vide, x, Vide)
                                   | Noeud(g, v, d) ->  if (x < v) then Noeud(insert g x, v, d)
                                                        else if (x > v) then Noeud(g, v, insert d x)
                                                        else Noeud(g, v, d);; 

insert exemple 10;;


(* EX 43 *)
let rec max = fun a -> match a with
                       | Vide -> min_int
                       | Noeud(g, v, d) -> if (d = Vide) then v else max d;;

let rec min = fun a -> match a with
                       | Vide -> max_int
                       | Noeud(g, v, d) -> if (g = Vide) then v else min g;;

let rec verif = fun a -> match a with
                         | Vide -> true;
                         | Noeud(g, v, d) -> let maxG = max g and minD = min d in
                                             if (maxG < v && v < minD) then (verif g) && (verif d)
                                             else false;;

let rec abrmind = fun (n : int) (arbre : abint) : int -> match arbre with
                                           | Vide -> n
                                           | Noeud(g,i,d) -> abrmind (min i n) d;;

let rec abrmaxg = fun (n : int) (arbre : abint) : int -> match arbre with
                                           | Vide -> n
                                           | Noeud(g,i,d) -> abrmaxg (max i n) g;;

let verif' = fun (arbre : abint) : bool -> match arbre with
                                                 | Vide -> true
                                                 | Noeud(g,i,d) -> if ((abrmaxg i g) <= i) && ((abrmind i d) >= i) then true else false;;

verif exemple;;
verif (Noeud(Noeud(Noeud(Vide,18,Vide),6,Noeud(Vide,7,Vide)),8,Noeud(Vide,9,Vide)));;
verif' exemple;;
verif' (Noeud(Noeud(Noeud(Vide,18,Vide),6,Noeud(Vide,7,Vide)),8,Noeud(Vide,9,Vide)));;


(* EX 44 : *)
let rec suppr = fun a -> fun x -> match a with
                                  | Vide -> Vide
                                  | Noeud(Vide, e, Vide) -> if (e = x)
                                                            then Vide
                                                            else Noeud(Vide, e, Vide)
                                  | Noeud(g, e, Vide) ->  if (e = x)
                                                          then let maxG = max g in Noeud(suppr g maxG, maxG, Vide)
                                                          else  if (x < e)
                                                                then Noeud(suppr g x, e, Vide)
                                                                else Noeud(g, e, Vide)
                                  | Noeud(Vide, e, d) ->  if (e = x)
                                                          then let minD = min d in Noeud(Vide, minD, suppr d minD)
                                                          else  if (x > e)
                                                                then Noeud(Vide, e, suppr d x)
                                                                else Noeud(Vide, e, d)
                                  | Noeud(g, e, d) ->  if (e = x)
                                                          then let maxG = max g in Noeud(suppr g maxG , maxG, d)
                                                          else  if (x < e)
                                                                then Noeud(suppr g x, e, d)
                                                                else Noeud(g, e, suppr d x);;

suppr exemple 10;;
suppr exemple 5;;
suppr exemple 7;;
suppr exemple 6;;
suppr exemple 3;;


(* EX 45 *)
let rec listeVersArbre = fun l -> fun a -> match l with
                                           | [] -> a
                                           | x::s -> listeVersArbre s (insert a x);;

let rec recupValeur = fun a -> match a with
                               | Vide -> []
                               | Noeud(g, v, d) -> (recupValeur g)@[v]@(recupValeur d);;

let triABR = fun l -> let a = (listeVersArbre l Vide) in
                      recupValeur a;;

triABR (4::1::6::3::8::2::[]);;


(* EX 46 *)
let rec minimum = fun i -> fun min -> match i with
                                      | [] -> min
                                      | x::s -> if (x < min) then minimum s x else minimum s min;;

let rec suppr_min = fun i -> fun min -> match i with
                                       | [] -> []
                                       | elem::ls -> if (elem = min)
                                                     then ls
                                                     else elem::(suppr_min ls min);;

let trouve_min = fun i -> match i with
                              | [] -> (min_int, [])
                              | elem::ls -> let min = minimum ls elem in
                                            let l = suppr_min i min in
                                            (min, l);;

let rec tri_selection = fun i -> match i with
                                 | [] -> []
                                 | _ -> let (min, s) = trouve_min i in
                                        min::(tri_selection s);;


let rec liste_alea = fun n -> match n with
                              | 0 -> []
                              | _ -> Random.int(100)::(liste_alea (n-1));;


let n = 10;;
let ex1 = liste_alea n;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection ex1 in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR ex1 in
          Sys.time() -. deb;;
(* Pour une liste de taille 10, les 2 méthodes sont à peu près équivalente avec un temps d'exécution d'environ 1 * 10^(-5)sec *)

let n = 100;;
let ex1 = liste_alea n;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection ex1 in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR ex1 in
          Sys.time() -. deb;;
(* Pour une liste de 100 éléments, le tri via ABR est légérement plus rapide avec un temps de 0.0001sec contre 0.0006sec pour le tri par sélection *)

let n = 1000;;
let ex1 = liste_alea n;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection ex1 in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR ex1 in
          Sys.time() -. deb;;
(* Pour une liste de 1000 éléments, le tri via ABR est toujours un peu plus rapide que le tri par sélection avec 0.0007sec contre 0.04sec*)

let rec liste_triee = fun i n -> if n = 0 then [] else i::(liste_triee (i+1) (n-1));;
let triee = liste_triee 0 1000;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection triee in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR triee in
          Sys.time() -. deb;;
(* Quand il s'agit d'une liste déjà triée, le tri par insertion est plus rapide que le tri par ABR avec un temps de 0.02sec contre 0.05sec *)


(* EX 47 *)
let rec verif2 = fun a -> match a with
                          | Vide -> (0, 0)
                          | Noeud(Vide, v, Vide) -> (v, v)
                          | Noeud(Vide, v, d) -> let (minD, maxD) = verif2 d in
                                                 if (v < minD) then (v, maxD)
                                                 else raise PasABR
                          | Noeud(g, v, Vide) -> let (minG, maxG) = verif2 g in
                                                 if (maxG < v) then (minG, v)
                                                 else raise PasABR
                          | Noeud(g, v, d) -> let (minG, maxG) = verif2 g and (minD, maxD) = verif2 d in
                                              if (maxG < v && v < minD) then (minG, maxD)
                                              else raise PasABR;;

verif2 exemple;;


(* EX 48 : *)
let rec concat = fun a1 -> fun a2 -> match a1 with
                                     | Vide -> a2
                                     | Noeud(g, v, d) -> concat g (concat d (insert a2 v));;

let rec aux = fun a -> fun x -> match a with
                                  | Vide -> (Vide, Vide)
                                  | Noeud(Vide, v, Vide) -> if (v < x) then (Noeud(Vide, v, Vide), Vide)
                                                            else if (v > x) then (Vide, Noeud(Vide, v, Vide))
                                                            else (Vide, Vide)
                                  | Noeud(g, v, d) -> let (a1G, a2G) = aux g x and (a1D, a2D) = aux d x in
                                                      if (v < x) then (concat a1G (insert a1D v), concat a2G a2D)
                                                      else if (v > x) then (concat a1G a1D, concat a2G (insert a2D v))
                                                      else (concat a1G a1D, concat a2G a2D);;

let split = fun a -> fun x -> if (mem a x) then aux a x else raise PasDansArbre;;


split exemple 5;;
split exemple 10;;
split exemple 7;;
split exemple 2;;


(* EX 49 *)
let racine = fun a -> match a with
                      | Vide -> raise ArbreVide
                      | Noeud(_, r, _) -> r;;

let compare = fun a1 -> fun a2 -> try
                                 let r = racine a1 in let (a1P, a1G) = split a1 r and (a2P, a2G) = split a2 r in
                                                      (a1P = a2P) && (a1G = a2G)
                               with
                               | PasDansArbre -> false
                               | ArbreVide -> false;;

compare exemple exemple;;
compare exemple Vide;;
compare Vide exemple;;
