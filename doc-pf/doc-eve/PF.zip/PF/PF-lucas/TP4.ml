(*
  Lucas DREZET : lucasdrezet@gmail.com
  Sami ELHADJI-TCHIAMBOU : sami3232@live.fr
  
  tout a ete fait
*)

#load "qtparser.cmo";;
open Qtparser;;

exception ArbreVide;;
exception PasDansArbre;;
exception PasABR;;
exception QuadtreesDifferents;;

Random.self_init();;


(* TP4 : DES ARBRES ET ENCORE DES ARBRES *)
(* 4.1. Arbres Binaires de Recherche *)
type abint =
  | Vide
  | Noeud of abint * int * abint;;

(* EX 40 *)
let exemple = Noeud(Noeud(Noeud(Vide, 2, Vide), 3, Vide), 5, Noeud(Noeud(Vide, 6, Noeud(Vide, 7, Vide)), 8, Noeud(Vide, 9, Vide)));;


(* EX 41 *)
let rec mem = fun a -> fun x -> match a with
                                | Vide -> false
                                | Noeud(g, v, d) -> if (v = x) then true
                                                    else if (x < v) then mem g x
                                                    else mem d x;; 

mem exemple 6;;
mem exemple 10;;

(* EX 42 *)
let rec insert = fun a -> fun x -> match a with
                                   | Vide -> Noeud(Vide, x, Vide)
                                   | Noeud(g, v, d) ->  if (x < v) then Noeud(insert g x, v, d)
                                                        else if (x > v) then Noeud(g, v, insert d x)
                                                        else Noeud(g, v, d);; 

insert exemple 10;;


(* EX 43 *)
let rec max = fun a -> match a with
                       | Vide -> min_int
                       | Noeud(g, v, d) -> if (d = Vide) then v else max d;;

let rec min = fun a -> match a with
                       | Vide -> max_int
                       | Noeud(g, v, d) -> if (g = Vide) then v else min g;;

let rec verif = fun a -> match a with
                         | Vide -> true;
                         | Noeud(g, v, d) -> let maxG = max g and minD = min d in
                                             if (maxG < v && v < minD) then (verif g) && (verif d)
                                             else false;;

verif exemple;;


(* EX 44 : *)
let rec suppr = fun a -> fun x -> match a with
                                  | Vide -> Vide
                                  | Noeud(Vide, e, Vide) -> if (e = x)
                                                            then Vide
                                                            else Noeud(Vide, e, Vide)
                                  | Noeud(g, e, Vide) ->  if (e = x)
                                                          then let maxG = max g in Noeud(suppr g maxG, maxG, Vide)
                                                          else  if (x < e)
                                                                then Noeud(suppr g x, e, Vide)
                                                                else Noeud(g, e, Vide)
                                  | Noeud(Vide, e, d) ->  if (e = x)
                                                          then let minD = min d in Noeud(Vide, minD, suppr d minD)
                                                          else  if (x > e)
                                                                then Noeud(Vide, e, suppr d x)
                                                                else Noeud(Vide, e, d)
                                  | Noeud(g, e, d) ->  if (e = x)
                                                          then let maxG = max g in Noeud(suppr g maxG , maxG, d)
                                                          else  if (x < e)
                                                                then Noeud(suppr g x, e, d)
                                                                else Noeud(g, e, suppr d x);;

suppr exemple 10;;
suppr exemple 5;;
suppr exemple 7;;
suppr exemple 6;;
suppr exemple 3;;


(* EX 45 *)
let rec listeVersArbre = fun l -> fun a -> match l with
                                           | [] -> a
                                           | x::s -> listeVersArbre s (insert a x);;

let rec recupValeur = fun a -> match a with
                               | Vide -> []
                               | Noeud(g, v, d) -> (recupValeur g)@[v]@(recupValeur d);;

let triABR = fun l -> let a = (listeVersArbre l Vide) in
                      recupValeur a;;

triABR (4::1::6::3::8::2::[]);;


(* EX 46 *)
let rec minimum = fun i -> fun min -> match i with
                                      | [] -> min
                                      | x::s -> if (x < min) then minimum s x else minimum s min;;

let rec suppr_min = fun i -> fun min -> match i with
                                       | [] -> []
                                       | elem::ls -> if (elem = min)
                                                     then ls
                                                     else elem::(suppr_min ls min);;

let trouve_min = fun i -> match i with
                              | [] -> (min_int, [])
                              | elem::ls -> let min = minimum ls elem in
                                            let l = suppr_min i min in
                                            (min, l);;

let rec tri_selection = fun i -> match i with
                                 | [] -> []
                                 | _ -> let (min, s) = trouve_min i in
                                        min::(tri_selection s);;


let rec liste_alea = fun n -> match n with
                              | 0 -> []
                              | _ -> Random.int(100)::(liste_alea (n-1));;


let n = 10;;
let ex1 = liste_alea n;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection ex1 in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR ex1 in
          Sys.time() -. deb;;
(* Pour une liste de taille 10, les 2 méthodes sont à peu près équivalente avec un temps d'exécution d'environ 1 * 10^(-5)sec *)

let n = 100;;
let ex1 = liste_alea n;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection ex1 in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR ex1 in
          Sys.time() -. deb;;
(* Pour une liste de 100 éléments, le tri via ABR est légérement plus rapide avec un temps de 0.0001sec contre 0.0006sec pour le tri par sélection *)

let n = 1000;;
let ex1 = liste_alea n;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection ex1 in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR ex1 in
          Sys.time() -. deb;;
(* Pour une liste de 1000 éléments, le tri via ABR est toujours un peu plus rapide que le tri par sélection avec 0.0007sec contre 0.04sec*)

let rec liste_triee = fun i n -> if n = 0 then [] else i::(liste_triee (i+1) (n-1));;
let triee = liste_triee 0 1000;;

let e1R1 = let deb = Sys.time() in
          let _ = tri_selection triee in
          Sys.time() -. deb;;

let e1E2 = let deb = Sys.time() in
          let _ = triABR triee in
          Sys.time() -. deb;;
(* Quand il s'agit d'une liste déjà triée, le tri par insertion est plus rapide que le tri par ABR avec un temps de 0.02sec contre 0.05sec *)


(* EX 47 *)
let rec verif2 = fun a -> match a with
                          | Vide -> (0, 0)
                          | Noeud(Vide, v, Vide) -> (v, v)
                          | Noeud(Vide, v, d) -> let (minD, maxD) = verif2 d in
                                                 if (v < minD) then (v, maxD)
                                                 else raise PasABR
                          | Noeud(g, v, Vide) -> let (minG, maxG) = verif2 g in
                                                 if (maxG < v) then (minG, v)
                                                 else raise PasABR
                          | Noeud(g, v, d) -> let (minG, maxG) = verif2 g and (minD, maxD) = verif2 d in
                                              if (maxG < v && v < minD) then (minG, maxD)
                                              else raise PasABR;;

verif2 exemple;;


(* EX 48 : *)
let rec concat = fun a1 -> fun a2 -> match a1 with
                                     | Vide -> a2
                                     | Noeud(g, v, d) -> concat g (concat d (insert a2 v));;

let rec aux = fun a -> fun x -> match a with
                                  | Vide -> (Vide, Vide)
                                  | Noeud(Vide, v, Vide) -> if (v < x) then (Noeud(Vide, v, Vide), Vide)
                                                            else if (v > x) then (Vide, Noeud(Vide, v, Vide))
                                                            else (Vide, Vide)
                                  | Noeud(g, v, d) -> let (a1G, a2G) = aux g x and (a1D, a2D) = aux d x in
                                                      if (v < x) then (concat a1G (insert a1D v), concat a2G a2D)
                                                      else if (v > x) then (concat a1G a1D, concat a2G (insert a2D v))
                                                      else (concat a1G a1D, concat a2G a2D);;

let split = fun a -> fun x -> if (mem a x) then aux a x else raise PasDansArbre;;


split exemple 5;;
split exemple 10;;
split exemple 7;;
split exemple 2;;


(* EX 49 *)
let racine = fun a -> match a with
                      | Vide -> raise ArbreVide
                      | Noeud(_, r, _) -> r;;

let compare = fun a1 -> fun a2 -> try
                                 let r = racine a1 in let (a1P, a1G) = split a1 r and (a2P, a2G) = split a2 r in
                                                      (a1P = a2P) && (a1G = a2G)
                               with
                               | PasDansArbre -> false
                               | ArbreVide -> false;;

compare exemple exemple;;
compare exemple Vide;;
compare Vide exemple;;


(* 4.2. Quadtrees *)

let blanc = Feuille(1);;
let noir = Feuille(0);;

let z1NO = Noeud(blanc, blanc, blanc, blanc);;
let z1NE = Noeud(blanc, blanc, blanc, noir);;
let z1SE = Noeud(noir, blanc, blanc, noir);;
let z1SO = Noeud(blanc, noir, blanc, noir);;
let z1 = Noeud(z1NO, z1NE, z1SE, z1SO);;

let z2NO = Noeud(blanc, blanc, noir, noir);;
let z2NE = Noeud(blanc, blanc, blanc, noir);;
let z2SE = Noeud(noir, blanc, blanc, noir);;
let z2SO = Noeud(noir, blanc, blanc, blanc);;
let z2 = Noeud(z2NO, z2NE, z2SE, z2SO);;

let z3NO = Noeud(blanc, noir, blanc, noir);;
let z3NE = Noeud(blanc, blanc, blanc, blanc);;
let z3SE = Noeud(noir, blanc, blanc, blanc);;
let z3SO = Noeud(noir, noir, blanc, blanc);;
let z3 = Noeud(z3NO, z3NE, z3SE, z3SO);;

let z4NO = Noeud(blanc, blanc, blanc, blanc);;
let z4NE = Noeud(noir, blanc, blanc, noir);;
let z4SE = Noeud(noir, blanc, blanc, blanc);;
let z4SO = Noeud(blanc, blanc, blanc, blanc);;
let z4 = Noeud(z4NO, z4NE, z4SE, z4SO);;

let douze = Noeud(z1, z2, z3, z4);;
save_qt 8 1 douze "douze.pgm";;


(* EX 50 *)
let rec rot_pos = fun q ->  match q with
                        | Noeud(no, ne, se, so) -> Noeud(rot_pos so, rot_pos no, rot_pos ne, rot_pos se)
                        | _ -> q;;

let rot_pos_douze = rot_pos douze;;
save_qt 8 1 rot_pos_douze "douze_rot_pos.pgm";;


(* EX 51 *)
let rec rot_neg = fun q ->  match q with
                        | Noeud(no, ne, se, so) -> Noeud(rot_neg ne, rot_neg se, rot_neg so, rot_neg no)
                        | _ -> q;;

let rot_neg_douze = rot_neg douze;;
save_qt 8 1 rot_neg_douze "douze_rot_neg.pgm";;

  
(* EX 52 *)
let rec miroir_hori = fun q -> match q with
                             | Noeud(no, ne, se, so) -> Noeud(miroir_hori so, miroir_hori se, miroir_hori ne, miroir_hori no)
                             | _ -> q;;

let hori_douze = miroir_hori douze;;
save_qt 8 1 hori_douze "douze_hori.pgm";;


(* EX 53 *)
let rec miroir_vert = fun q -> match q with
                          | Noeud(no, ne, se, so) -> Noeud(miroir_vert ne, miroir_vert no, miroir_vert so, miroir_vert se)
                          | _ -> q;;

let vert_douze = miroir_vert douze;;
save_qt 8 1 vert_douze "douze_vert.pgm";;


(* EX 54 *)
let rec inversion_video = fun q -> fun niv_max -> match q with
                                                  | Feuille(n) -> Feuille( (n + niv_max) mod (niv_max + 1) )
                                                  | Noeud(no, ne, se, so) -> Noeud(inversion_video no niv_max, inversion_video ne niv_max, inversion_video se niv_max, inversion_video so niv_max);;

let inv_douze = inversion_video douze 1;;
save_qt 8 1 inv_douze "douze_inv.pgm";;


(* EX 55 *)
let rec max_gris = fun q -> match q with
                            | Feuille(n) -> n
                            | Noeud(no, ne, se, so) -> let maxNO = max_gris no and maxNE = max_gris ne and maxSE = max_gris se and maxSO = max_gris so in
                                                       max maxNO (max maxNE (max maxSE maxSO));;

max_gris douze;;
max_gris blanc;;
max_gris noir;;
max_gris (Noeud(blanc, noir, blanc, blanc));;


(* EX 56 *)
let rec aux_compare = fun q -> fun v -> match q with
                                          | Feuille(n) -> if n = v then true else raise QuadtreesDifferents
                                          | Noeud(no, ne, se, so) -> aux_compare no v && aux_compare ne v && aux_compare se v && aux_compare so v;;

let rec compare = fun q1 -> fun q2 -> try
                            match q1, q2 with
                                      | Feuille(n1), Feuille(n2) -> if n1 = n2 then true else raise QuadtreesDifferents
                                      | Feuille(n1), qt -> aux_compare qt n1
                                      | qt, Feuille(n2) -> aux_compare qt n2
                                      | Noeud(no1, ne1, se1, so1), Noeud(no2, ne2, se2, so2) -> compare no1 no2 && compare ne1 ne2 && compare se1 se2 && compare so1 so2
                                   with
                                   | QuadtreesDifferents -> false;;

compare douze douze;;
compare douze inv_douze;;


(* EX 57 *)
let rec aux_compare2 = fun q -> fun v -> match q with
                                          | Feuille(n) -> n = v
                                          | Noeud(no, ne, se, so) -> aux_compare2 no v && aux_compare2 ne v && aux_compare2 se v && aux_compare2 so v;;

let rec compare2 = fun q1 -> fun q2 -> match q1, q2 with
                                      | Feuille(n1), Feuille(n2) -> if n1 = n2 then (blanc, blanc) else (Feuille(n1), Feuille(n2))
                                      | Feuille(n1), qt -> if aux_compare2 qt n1 then (blanc, blanc) else (Feuille(n1), qt)
                                      | qt, Feuille(n2) -> if aux_compare2 qt n2 then (blanc, blanc) else (qt, Feuille(n2))
                                      | Noeud(no1, ne1, se1, so1), Noeud(no2, ne2, se2, so2) -> let (noRes1, noRes2) = compare2 no1 no2 in
                                                                                                if (noRes1, noRes2) != (blanc, blanc) then (noRes1, noRes2) else
                                                                                                  let (neRes1, neRes2) = compare2 ne1 ne2 in
                                                                                                  if (neRes1, neRes2) != (blanc, blanc) then (noRes1, noRes2) else
                                                                                                    let (seRes1, seRes2) = compare2 se1 se2 in
                                                                                                    if (seRes1, seRes2) != (blanc, blanc) then (seRes1, seRes2) else
                                                                                                      let (soRes1, soRes2) = compare2 so1 so2 in
                                                                                                      if (soRes1, soRes2) != (blanc, blanc) then (soRes1, soRes2) else (blanc, blanc);;

compare2 douze douze;;
compare2 douze inv_douze;;


(* EX 58 *)
let rec min_quad = fun q -> match q with
                            | Noeud(Feuille(no), Feuille(ne), Feuille(se), Feuille(so)) -> if (no = ne && ne = se && se = so) then Feuille(no) else q
                            | Noeud(no, ne, se, so) -> let minNO = min_quad no and minNE = min_quad ne and minSE = min_quad se and minSO = min_quad so in
                                                       if (compare minNO minNE) && (compare minNE minSE) && (compare minSE minSO) then minNO else Noeud(minNO, minNE, minSE, minSO)
                            | _ -> q;;

min_quad (Noeud(Noeud(blanc, Noeud(blanc, blanc, blanc, blanc), blanc, blanc), blanc, blanc, Noeud(blanc, blanc, blanc, blanc)));;
min_quad (Noeud(Noeud(blanc, Noeud(blanc, blanc, blanc, blanc), noir, blanc), blanc, blanc, Noeud(blanc, blanc, blanc, blanc)));;
min_quad (Noeud(Noeud(blanc, Noeud(blanc, blanc, noir, blanc), blanc, blanc), blanc, blanc, Noeud(blanc, blanc, blanc, blanc)));;


(* EX 59 *)
type mixtree =
  | Q of quadtree * int
  | T of recttree and
recttree = NoeudT of mixtree * mixtree * mixtree * mixtree;;

let rec taille_rect = fun r -> let NoeudT(m1, m2, m3, m4) = r in
                               let (tm1, tm1') = taille_mix m1 and (tm2, tm2') = taille_mix m2 and (tm3, tm3') = taille_mix m3 and (tm4, tm4') = taille_mix m4 in
                               ((max tm1 tm4) + (max tm2 tm3), (max tm1' tm2') + (max tm3' tm4'))
and taille_mix = fun m -> match m with
                              | Q(q, t) -> (t, t)
                              | T(r) -> taille_rect r;; 

taille_rect (NoeudT(Q(douze, 0), Q(douze, 0), Q(douze, 0), Q(douze, 8)));;
taille_rect (NoeudT(Q(douze, 8), Q(douze, 0), Q(douze, 0), Q(douze, 8)));;
taille_rect (NoeudT(Q(douze, 8), Q(douze, 8), Q(douze, 0), Q(douze, 0)));;
taille_rect (NoeudT(Q(douze, 0), Q(douze, 8), Q(douze, 8), Q(douze, 8)));;


(* EX 60 *)
let rec max_mixtree = fun m -> fun maxT -> match m with
                               | Q(q, t) -> max maxT t
                               | T(NoeudT(m1, m2, m3, m4)) -> let maxM1 = max_mixtree m1 maxT and maxM2 = max_mixtree m2 maxT and maxM3 = max_mixtree m3 maxT and maxM4 = max_mixtree m4 maxT in
                                                              max maxM1 (max maxM2 (max maxM3 maxM4));;

let rect_valide = fun r -> let NoeudT(m1, m2, m3, m4) = r in
                           match m1 with
                           | Q(q, t) -> t >= max_mixtree m2 0 && t >= max_mixtree m3 0 && t >= max_mixtree m4 0
                           | _ -> false;;

rect_valide (NoeudT(Q(douze, 0), Q(douze, 0), Q(douze, 0), Q(douze, 8)));;
rect_valide (NoeudT(Q(douze, 8), Q(douze, 0), Q(douze, 0), Q(douze, 8)));;
rect_valide (NoeudT(Q(douze, 8), Q(douze, 8), Q(douze, 0), Q(douze, 0)));;
rect_valide (NoeudT(Q(douze, 0), Q(douze, 8), Q(douze, 8), Q(douze, 8)));;
