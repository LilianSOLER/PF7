(* EX 18 *)
(* 1. *)
type direction_absolue =
  | Nord
  | Sud
  | Est
  | Ouest;;

type direction_relative =
  | Droite
  | Gauche;;

let td = fun dir_abs -> match dir_abs with
                        | Nord -> Est
                        | Sud -> Ouest
                        | Est -> Sud
                        | Ouest -> Nord;;

let tg = fun dir_abs -> match dir_abs with
                        | Nord -> Ouest
                        | Sud -> Est
                        | Est -> Nord
                        | Ouest -> Sud;;

let changer_direction = fun dir_abs -> fun dir_rel -> match dir_rel with
                                                      | Droite -> td dir_abs
                                                      | Gauche -> tg dir_abs;;

type coordonnes = C of int * int;;

let mouvoir = fun pos -> fun dir -> fun dist -> let C(x, y) = pos in
                                                match dir with
                                                | Nord -> C(x, y + dist)
                                                | Sud -> C(x, y - dist)
                                                | Est -> C(x + dist, y)
                                                | Ouest -> C(x - dist, y);;

(* 2. *)
type legume =
  | Haricot
  | Carotte
  | Courge;;

type fleur =
  | Rose
  | Tulipe
  | Orchidee;;

type fruit =
  | Pomme
  | Poire
  | Banane;;

type couleur =
  | Jaune
  | Rose
  | Rouge;;

type plante =
  | Legume of legume
  | Fleur of fleur * couleur
  | Fruit of fruit;;


(* EX 7 *)
let rec fact = fun n -> match n with
                        | 0
                          | 1 -> 1
                        | _ -> n * fact (n-1);;


(* EX 8 *)
let rec puis = fun x -> fun n -> match n with
                                 | 0 -> 1
                                 | _ -> x * (puis x (n - 1));;

let rec puis_terminal = fun x -> fun n -> fun res -> if (n = 0) then res else puis_terminal x (n - 1) (res * x);;


(* EX 22 *)
let rec nb = fun l -> match l with
                      | [] -> 0
                      | x::s -> 1 + nb s;;
