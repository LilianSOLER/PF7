(*
    Lucas DREZET : lucasdrezet@gmail.com
    Sami ELHADJI-TCHIAMBOU : sami3232@live.fr
  
    
*)

(* Grammaire :
  V ::= a | b | c | d
  C ::= 0 | 1
  E ::= V | C
  S ::= IL | ε
  L ::= ;S | ε
  I ::= V:=E | i.E{S}{S} | w.E{S} | ε

Travail à effectuer :
- Écrivez une autre version de anacomb.ml (anacomblazy.ml), qui utilise
  des listes paresseuses
- Écrivez une autre version de vos fonctions qui utilisent les listes paresseuses


- facultatif (pas pour les paresseux donc):
  Écrivez une autre version de vos fonctions qui utilisent le type
  Stream.t (https://caml.inria.fr/pub/docs/manual-ocaml/libref/Stream.html)
 *)

exception Echec;;

type v =
  | A
  | B
  | C
  | D;;

type c =
  | Zero
  | Un;;

type e =
  | Variable of v
  | Constante of c;;

type s =
  | ListeInstruction of i * l
  | EpsilonS
and
l =
  | PS of s
  | EpsilonL
and
  i =
  | Affectation of v * e
  | If of e * s * s
  | While of e * s
  | EpsilonI;;

let stringToList = fun s -> let rec boucle s i n = if i = n then [] else s.[i] :: boucle s (i+1) n
                            in boucle s 0 (String.length s);;

let lireCaractere = fun c -> fun l -> match l with
                                      | x::l when x = c -> l
                                      | _ -> raise Echec;;

let lireExpr = fun l -> match l with
                        | '0'::s -> Constante Zero, s
                        | '1'::s -> Constante Un, s
                        | 'a'::s -> Variable A, s
                        | 'b'::s -> Variable B, s
                        | 'c'::s -> Variable C, s
                        | 'd'::s -> Variable D, s
                        | _ -> raise Echec;;

let lireVar = fun l ->  match l with
                        | 'a'::s -> A, s
                        | 'b'::s -> B, s
                        | 'c'::s -> C, s
                        | 'd'::s -> D, s
                        | _ -> raise Echec;;

let (+>) a b = fun l -> let l = a l in b l;;

let (++>) a b = fun l -> let (x, l) = a l in b x l;;

let (+|) a b = fun l -> try a l with
                        | Echec -> b l;;

let return = fun x l -> (x, l);;

let rec pS = fun l -> l |> (pI ++> fun i -> pL ++> fun li -> return (ListeInstruction (i, li)))
                           +| pES
  and
    pL = fun l -> l |> (lireCaractere ';' +> pS ++> fun s -> return (PS (s)))
                       +| pEL
  and
    pI = fun l -> l |>  (lireCaractere 'i' +> lireCaractere '(' +> lireExpr ++> fun e -> lireCaractere ')' +> lireCaractere '{' +> pS ++> fun s1 -> lireCaractere '}' +> lireCaractere '{' +> pS ++> fun s2 -> lireCaractere '}' +> return (If (e, s1, s2)))
                        +| (lireCaractere 'w' +> lireCaractere '(' +> lireExpr ++> fun e -> lireCaractere ')' +> lireCaractere '{' +> pS ++> fun s -> lireCaractere '}' +> return (While (e, s)))
                        +| (lireVar ++> fun v -> lireCaractere ':' +> lireCaractere '=' +> lireExpr ++> fun e -> return (Affectation (v, e)))
                        +| pEI
  and
    pES = fun l -> EpsilonS, l
  and
    pEL = fun l -> EpsilonL, l
  and
    pEI = fun l -> EpsilonI, l
;;


let parser = fun s ->
  try
    let ast, res = pS (stringToList s) in
    match res with
    | [] -> (ast, true)
    | _ -> (EpsilonS, false)
  with
  | Echec -> (EpsilonS, false);;


(* TEST *)
parser ";";;
parser "a";;
parser "a:";;
parser "a:=";;

parser "a:=1";;
parser "b:=0";;
parser "c:=1;";;
parser "d:=0;";;

parser "i(d){;}{}";;
parser "w(a){c:=0}";;
parser "i(c){c:=0;a:=b}{b:=0;c:=a}";;

parser "a:=1;b:=1;c:=1;w(a){i(c){c:=0;a:=b}{b:=0;c:=a}}";;
