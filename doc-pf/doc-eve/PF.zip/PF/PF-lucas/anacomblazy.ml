(* Analyse descendante récursive sur une liste *)
exception Echec;;

type 'term analistinf = unit -> 'term contentlist
and
'term contentlist = | Cons of 'term * 'term analistinf
                    | Nil;;

let rec get n l = match n,l with
  | 0, Cons(x, s) -> []
  | 0, Nil -> []
  | n, Cons(x, s) -> x::(get (n-1) (s ()))
  | _ -> raise Echec;;

(* Utilitaire pour les tests *)

(* Le type des fonctions qui épluchent une liste de terminaux *)

let rec toList s i n = fun () -> if (i = n) then Nil else Cons((s.[i]), toList s (i+1) n);;

(* Le type des fonctions qui épluchent une liste et rendent un résultat *)
(* type ('r, 'term) ranalist = 'term list -> 'r * 'term list;; *)

let terminal c = fun l -> match l with
  | Cons(x, l) when x = c -> l
  | _ -> raise Echec;;

(* ------------------------------------------------------------ *)
(* Combinateurs d'analyseurs
   Sans calcul d'AST *)
(* ------------------------------------------------------------ *)

(* a suivi de b *)
let (+>) a b = fun l -> let l = a l in b l;;

(* choix entre a ou b *)
let (+|) a b = fun l -> try a l with Echec -> b l;;

(* ---------------------------------- *)
(* Grammaire non récursive *)

(* 
    S0  ::=  'x'
    S   ::=  '(' S0 ')'  |  'x'
 *)

let lire = fun l -> l ();;

let p_S0 = terminal 'x';;
let p_S = (terminal '(' +> lire +> p_S0 +> lire +> terminal ')')
          +| (terminal 'x');;

let parser s = let l = toList s 0 (String.length s) in
               p_S (l ());;

parser "";;
parser "x";;
parser "(x";;
parser "x)";;
parser "(x)";;
parser "xouinouin";;
parser "x)ouinouin";;
parser "(x)ouinouin";;


(* ---------------------------------- *)
(* Grammaire récursive *)

(* 
    S0  ::=  'x'
    S   ::=  '(' S ')'  |  'x'
*)


(* 
   En OCaml, x |> f est une autre notation de f x.
   Le let rec impose l'explicitation d'au moins un argument,
   d'où le démarrage par fun l -> l |>
*)

let rec p_S = fun l ->  l |> (terminal '(' +> lire +> p_S +> lire +> terminal ')')
                             +| (terminal 'x');;

let parser s = let l = toList s 0 (String.length s) in
               p_S (l ());;

parser "(((x)))abc";;
parser "xabc";;
parser "((x))abc";;
parser "()abc";;


(* ------------------------------------------------------------ *)
(* Combinateurs d'analyseurs
   Avec calcul d'AST *)
(* ------------------------------------------------------------ *)

(* Un type commun pour 't analist ou ('r, 't) ranalist *)
type ('x, 't) st = 't list -> 'x

(* a suivi de b, ce dernier pouvant rendre un résultat *)
let (+>) a b = fun l -> let l = a l in b l;;

(* a rendant un résultat suivi de b, ce dernier pouvant rendre un résultat *)
let (++>) a b = fun l -> let (x, l) = a l in b x l;;

(* Choix entre a ou b *)
let (+|) a b = fun l -> try a l with Echec -> b l;;

(* *)
let return = fun x l -> (x, l);;
