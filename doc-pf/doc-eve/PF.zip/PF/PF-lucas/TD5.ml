(*
  TD5
 *)


(* EX 89 *)
let compose_fonctions1 f g = fun x -> g (f x);;
let compose_fonctions2 f g = fun x -> let (b, c) = f x in g b c;;


(* EX 91 *)
let curry f = fun x -> fun y -> f(x, y);;
let uncurry f = fun (x, y) -> f x y;;
compose_fonctions1 curry (uncurry);;
compose_fonctions1 uncurry (curry);;


(* EX 112 *)
exception Impossible;;
type 'a inflist = unit -> 'a contentsil
and
'a contentsil = Cons of 'a * 'a inflist;;

let rec bits1 n = fun() ->  match n with
                          | 0 -> Cons(0, bits1 1)
                          | 1 -> Cons(1, bits1 0)
                          | _ -> raise Impossible;;

let rec bits2 n = fun() -> Cons(n, bits2 ((n + 1) mod 2));;

let peek l = match l with
  | Cons(x, _) -> x;;
                 
let rec suppr n l = match n,l with
  | 0, Cons(x, s) -> Cons(x, s)
  | n, Cons(x, s) -> suppr (n-1) (s ());;

let rec get n l = match n,l with
  | 0, Cons(x, s) -> []
  | n, Cons(x, s) -> x::(get (n-1) (s ()));;

let rec iterate f x = fun () -> Cons(x, iterate f (f x));;


(* EX 92 *)
let rec listf n = if(n > 0) then ((+) n)::(listf (n - 1)) else [];;
